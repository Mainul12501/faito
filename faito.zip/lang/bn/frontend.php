<?php

return [
    'home' =>
    [ 
        'motto' => 'আমাদের নীতিবাক্য',
        ]

];