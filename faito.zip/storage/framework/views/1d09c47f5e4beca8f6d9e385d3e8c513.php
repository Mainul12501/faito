

<?php $__env->startSection('title', 'Create Bike Engine Size'); ?>

<?php $__env->startSection('body'); ?>
    <div class="row mt-5">
        <div class="col-md-6 mx-auto">
            <div class="card">
                <div class="card-header">
                    <h3><?php echo e(isset($bikeEngineSize) ? 'update' : 'Create'); ?> Bike Engine Size</h3>
                    <a href="<?php echo e(route('admin.bike-engine-sizes.index')); ?>" class="btn btn-success btn-sm position-absolute me-5" style="right: 0"><i class="fa fa-sliders"></i></a>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(isset($bikeEngineSize) ? route('admin.bike-engine-sizes.update', $bikeEngineSize->id) : route('admin.bike-engine-sizes.store')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php if(isset($bikeEngineSize)): ?>
                            <?php echo method_field('put'); ?>
                        <?php endif; ?>
                        <div class="row mt-3">
                            <label for="" class="col-md-4">Name</label>
                            <div class="col-md-8">
                                <input type="text" name="name" class="form-control" value="<?php echo e(isset($bikeEngineSize) ? $bikeEngineSize->name : ''); ?>" placeholder="Bike Enzine Size Name" />
                            </div>
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($errors->first('name')); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="row mt-3">
                            <label for="" class="col-md-4">Info</label>
                            <div class="col-md-8">
                                <textarea type="text" name="info" class="form-control ckeditor" placeholder="Bike Engine Size Info" id="" cols="30" rows="5"><?php echo e(isset($bikeEngineSize) ? $bikeEngineSize->info : ''); ?></textarea>
                            </div>
                        </div>

                        <div class="row mt-3">
                            <label for="" class="col-md-4">Status</label>
                            <div class="col-md-8">
                                <div class="material-switch">
                                    <input id="someSwitchOptionLight" name="status" type="checkbox" <?php echo e(isset($bikeEngineSize) && $bikeEngineSize->status == 0 ? '' : 'checked'); ?> />
                                    <label for="someSwitchOptionLight" class="label-light"></label>
                                </div>
                            </div>
                        </div>
                        <div class="row mt-3">
                            <label for="" class="col-md-4"></label>
                            <div class="col-md-8">
                                <input type="submit" class="btn btn-success" value="<?php echo e(isset($bikeEngineSize) ? 'update' : 'Create'); ?> Bike Engine Size">
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laravel\faito_app\resources\views/backend/bike-management/bike-engine-size/create.blade.php ENDPATH**/ ?>