<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<meta name="title" content="Home">
<meta name="description" content="&lt;p&gt;Tseatadasdasdasdadssadasdsadasdsadasad&lt;/p&gt;">
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
<?php /**PATH H:\wamp64\www\faito\resources\views/frontend/includes/assets/meta.blade.php ENDPATH**/ ?>