

<?php $__env->startSection('title', 'Create Bike Motor Type'); ?>

<?php $__env->startSection('body'); ?>
    <div class="row mt-5">
        <div class="col-md-6 mx-auto">
            <div class="card">
                <div class="card-header">
                    <h3><?php echo e(isset($bikeMotorType) ? 'update' : 'Create'); ?> Bike Motor Type</h3>
                    <a href="<?php echo e(route('admin.bike-motor-types.index')); ?>" class="btn btn-success btn-sm position-absolute me-5" style="right: 0"><i class="fa fa-sliders"></i></a>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(isset($bikeMotorType) ? route('admin.bike-motor-types.update', $bikeMotorType->id) : route('admin.bike-motor-types.store')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php if(isset($bikeMotorType)): ?>
                            <?php echo method_field('put'); ?>
                        <?php endif; ?>
                        <div class="row mt-3">
                            <label for="" class="col-md-4">Name</label>
                            <div class="col-md-8">
                                <input type="text" name="name" class="form-control" value="<?php echo e(isset($bikeMotorType) ? $bikeMotorType->name : ''); ?>" placeholder="Bike Motor Type Name" />
                            </div>
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($errors->first('name')); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="row mt-3">
                            <label for="" class="col-md-4">Other Info</label>
                            <div class="col-md-8">
                                <textarea type="text" name="other_info" class="form-control ckeditor" placeholder="Bike Motor Type Other Info" id="" cols="30" rows="5"><?php echo e(isset($bikeMotorType) ? $bikeMotorType->other_info : ''); ?></textarea>
                            </div>
                        </div>
                        <div class="row mt-3">
                            <label for="" class="col-md-4">Image</label>
                            <div class="col-md-8">
                                <input type="file" name="image" class="form-control" placeholder="Bike Motor Type Image" accept="">
                                <?php if(isset($bikeMotorType)): ?>
                                    <img src="<?php echo e(asset($bikeMotorType->image)); ?>" alt="" style="height: 80px">
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="row mt-3">
                            <label for="" class="col-md-4">Status</label>
                            <div class="col-md-8">
                                <div class="material-switch">
                                    <input id="someSwitchOptionLight" name="status" type="checkbox" <?php echo e(isset($bikeMotorType) && $bikeMotorType->status == 0 ? '' : 'checked'); ?> />
                                    <label for="someSwitchOptionLight" class="label-light"></label>
                                </div>
                            </div>
                        </div>
                        <div class="row mt-3">
                            <label for="" class="col-md-4"></label>
                            <div class="col-md-8">
                                <input type="submit" class="btn btn-success" value="<?php echo e(isset($bikeMotorType) ? 'update' : 'Create'); ?> Bike Motor Type">
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laravel\faito_app\resources\views/backend/bike-management/bike-motor-type/create.blade.php ENDPATH**/ ?>