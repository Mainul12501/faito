<?php $__currentLoopData = $partsBrandCategory->partsBrandCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $subCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <option value="<?php echo e($subCategory->id); ?>" <?php echo e(isset($partsProduct) && $partsProduct->parts_brand_category_id == $subCategory->id ? 'selected' : ''); ?> >
        <?php for($i = 0; $i <= $child; $i++): ?>
            <?php echo e('>'); ?>

        <?php endfor; ?>
        <?php echo e($subCategory->name); ?>

    </option>
    <?php if(!empty($subCategory)): ?>
        <?php if(count($partsBrandCategory->partsBrandCategories) > 0): ?>
            <?php echo $__env->make('backend.parts-management.parts-product.category-loop', ['partsBrandCategory' => $subCategory, 'child' => $child + $child], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\Users\Mainul Islam\Downloads\Compressed\temp\faito-app\v1\faito_app\resources\views/backend/parts-management/parts-product/category-loop.blade.php ENDPATH**/ ?>