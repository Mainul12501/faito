<link rel="stylesheet" href="<?php echo e(asset('/')); ?>frontend/assets/fe/css/styles.min.css">

<?php echo $__env->yieldContent('css'); ?>
<?php echo $__env->yieldPushContent('css'); ?>
<?php /**PATH C:\Users\Mainul Islam\Downloads\Compressed\temp\faito-app\faito_app\resources\views/frontend/includes/assets/css.blade.php ENDPATH**/ ?>