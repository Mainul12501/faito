<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH D:\Works\laravel\faito_app_updated_09022024\faito_app\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>