

<?php $__env->startSection('title', isset($blog) ? 'Edit' : 'Create'.' Blog '); ?>

<?php $__env->startSection('body'); ?>
    <div class="row py-5">
        <div class="col-md-9 mx-auto">
            <div class="card">
                <div class="card-header bg-light">
                    <h3><?php echo e(isset($blog) ? 'Edit' : 'Create'); ?> Blog </h3>
                    <a href="<?php echo e(route('admin.blogs.index')); ?>" class="btn btn-success btn-sm position-absolute me-5" style="right: 0"><i class="fa fa-sliders"></i></a>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(isset($blog) ? route('admin.blogs.update', $blog->id) : route('admin.blogs.store')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php if(isset($blog)): ?>
                            <?php echo method_field('put'); ?>
                        <?php endif; ?>
                        <div class="row mt-2">
                            <label for="" class="col-md-3">Category Name</label>
                            <div class="col-md-9 form-group">
                                <select name="blog_category_id" required id="" class="form-control select2">
                                    <option value="" disabled selected>Select a Category</option>
                                    <?php $__currentLoopData = $blogCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blogCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($blogCategory->id); ?>" <?php echo e(isset($blog) && $blogCategory->id == $blog->blog_category_id ? 'selected' : ''); ?>><?php echo e($blogCategory->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="row mt-4">
                            <label for="" class="col-md-3">Blog Title*</label>
                            <div class="col-md-9">
                                <input type="text" name="title" class="form-control" placeholder="Blog Title" value="<?php echo e(isset($blog) ? $blog->title : ''); ?>" />
                            </div>
                        </div>
                        <div class="row mt-4">
                            <label for="" class="col-md-3">Blog Image</label>
                            <div class="col-md-9">
                                <input type="file" name="image" class="form-control" accept="image/*" id="imagez" />
                                <?php if(isset($blog)): ?>
                                    <img src="<?php echo e(asset($blog->image)); ?>" alt="" style="height: 80px" />
                                <?php endif; ?>
                            </div>
                            <div class="col-md-3 mt-2">
                                <div>
                                    <img src="" id="imagePreview" alt="">
                                </div>
                            </div>
                        </div>
                        <div class="row mt-3">
                            <div class="col-12">
                                <label for="" class="col-md-3">Content</label>
                                <div class="">
                                    <textarea name="content" id="" class="form-control ckeditor" placeholder="Answer"><?php echo e(isset($blog) ? $blog->content : ''); ?></textarea>
                                </div>
                            </div>
                        </div>
                        <div class="row mt-4">
                            <label for="" class="col-md-3">Status</label>
                            <div class="col-md-9">
                                <div class="material-switch">
                                    <input id="someSwitchOptionLight" name="status" type="checkbox" <?php echo e(isset($blog) && $blog->status == 0 ? '' : 'checked'); ?> />
                                    <label for="someSwitchOptionLight" class="label-light"></label>
                                </div>
                            </div>
                        </div>
                        <div class="row mt-4">
                            <label for="" class="col-md-3"></label>
                            <div class="col-md-9">
                                <input type="submit" class="btn btn-success" value="<?php echo e(isset($blog) ? 'Update' : 'Create'); ?> Blog ">
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    image<script>
        $(document).ready(function() {
            $('#imagez').change(function() {
                var imgURL = URL.createObjectURL(event.target.files[0]);
                $('#imagePreview').attr('src', imgURL).css({
                    height: 150+'px',
                    width: 150+'px',
                    marginTop: '5px'
                });
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Works\laravel\faito_app_updated_09022024\faito_app\resources\views/backend/blog-management/blogs/form.blade.php ENDPATH**/ ?>