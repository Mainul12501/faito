<!DOCTYPE html>
<html>

<head>
    <?php echo $__env->make('frontend.includes.assets.meta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Faito | <?php echo $__env->yieldContent('title'); ?></title>

    <link rel="icon" href="<?php echo e(asset('/')); ?>frontend/assets/contents/Y1nunJilpj.png">

    <!--Style-->
    <!--build:css css/styles.min.css-->

    <?php echo $__env->make('frontend.includes.assets.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--endbuild-->

    <!--js-->
    <!--build:js js/main.min.js -->

    <script>
      const BASEURL = "<?php echo url('/'); ?>" + '/';
      
    </script>
    <?php echo $__env->make('frontend.includes.assets.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--endbuild-->
</head>
<body>

<!-- header -->
<?php echo $__env->make('frontend.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- end of header --><!-- middle -->
<!-- middle -->

<?php echo $__env->yieldContent('body'); ?>

<!-- end of middle -->
<!-- end of middle -->
<!--Footer -->
<?php echo $__env->make('frontend.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--end of Footer -->
</body>

</html>
<?php /**PATH D:\xampp\htdocs\faito_app\resources\views/frontend/master.blade.php ENDPATH**/ ?>