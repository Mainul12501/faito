

<?php $__env->startSection('title', 'Manage Parts Product'); ?>

<?php $__env->startSection('body'); ?>
    <div class="row mt-5">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header bg-light">
                    <h3>Manage parts Product</h3>
                    <a href="<?php echo e(route('admin.parts-products.create')); ?>" class="btn btn-success btn-sm position-absolute me-5"
                       style="right: 0"><i class="fa fa-plus-circle"></i></a>
                </div>
                <div class="card-body">
                    <div class="table-responsive export-table">
                        <table class="table" id="file-datatable">
                            <thead>
                                <th>#</th>
                                <th>Parts Brand Category</th>
                                <th>Title</th>
                                <th>Sub Title</th>
                                <th>Short Description</th>
                                <th>Long Description</th>
                                <th>Features</th>
                                <th>Sku</th>
                                <th>Sub Images</th>
                                <th>Bikes</th>
                                <th>Vendors</th>
                                <th>Status</th>
                                <th>Action</th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $partsProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partsProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($partsProduct->partsBrandCategory->name); ?></td>
                                        <td><?php echo e($partsProduct->title); ?></td>
                                        <td><?php echo e($partsProduct->sub_title); ?></td>
                                        <td><?php echo str()->words($partsProduct->short_description, 20, '....'); ?></td>
                                        <td><?php echo str()->words($partsProduct->long_description, 20, '....'); ?></td>
                                        <td><?php echo str()->words($partsProduct->features, 20, '....'); ?></td>
                                        <td><?php echo e($partsProduct->sku); ?></td>
                                        <td>
                                            <div>
                                                <img src="<?php echo e(asset($partsProduct->main_image)); ?>" alt="" style="height: 60px" />
                                            </div>
                                            <div class="mt-2">
                                                <?php if(!empty($partsProduct->sub_images)): ?>
                                                    <?php $__currentLoopData = json_decode($partsProduct->sub_images); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <img src="<?php echo e(asset($sub_image)); ?>" alt="ete" height="40" class="px-2" />
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                        <td>
                                            <?php if(!empty($partsProduct->motorBikes)): ?>
                                                <?php $__currentLoopData = $partsProduct->motorBikes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $motorBike): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <p class="badge badge-success-light"><?php echo e($motorBike->model_name); ?></p>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <div class="">
                                                <?php if(!empty($partsProduct->marketVerdors)): ?>
                                                    <?php $__currentLoopData = $partsProduct->marketVerdors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marketVerdor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <p class="badge badge-success-light"><?php echo e($marketVerdor->name); ?></p>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                        <td><?php echo e($partsProduct->status == 1 ? 'Published' : 'Unpublished'); ?></td>
                                        <td class="d-flex">
                                            <a href="<?php echo e(route('admin.parts-products.edit', $partsProduct->id)); ?>"
                                               class="btn btn-sm btn-primary"><i class="fa fa-edit"></i></a>
                                            <form action="<?php echo e(route('admin.parts-products.destroy', $partsProduct->id)); ?>"
                                                  method="post" id="deleteItem">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('delete'); ?>
                                                <button type="submit" class="btn btn-sm btn-danger ms-1 delete-item"><i
                                                        class="fa fa-trash"></i></button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Works\laravel\faito_app_updated_09022024\faito_app\resources\views/backend/parts-management/parts-product/index.blade.php ENDPATH**/ ?>