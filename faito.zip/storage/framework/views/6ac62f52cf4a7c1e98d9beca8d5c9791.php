<?php $__env->startSection('body'); ?>
    <section class="banner-landing">
        <figure>
            <img src="<?php echo e(asset('/')); ?>frontend/assets/contents/lxx0CHAACE.png" alt="">
        </figure>
        <div class="text-absolute">
            <h2>FAQ</h2>
            <span><img src="<?php echo e(asset('/')); ?>frontend/assets/images/material/shape-img-abs.html" alt=""></span>
        </div>
        <span class="shape-banner"><img src="<?php echo e(asset('/')); ?>frontend/assets/images/material/shape-banner.html" alt=""></span>
    </section>

    <section class="content-landing">
        <div class="wrapper">
            <div class="middle">
                <div class="title-landing full">
                    <div class="title">
                        <span class="line-text"></span>
                        <small>FAQ</small>
                        <h3>FAQ</h3>
                    </div>
                </div>
                <div class="accordion">
                    <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="list-acc">
                        <div class="grid-acc">
                            <h5><?php echo e($faq->question ?? ''); ?></h5>
                            <div class="plus">
                                <span></span>
                                <span></span>
                            </div>
                        </div>
                        <div class="content-acc text-content">
                            <p><?php echo $faq->answer; ?></p>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Works\laravel\faito_app_updated_09022024\faito_app\resources\views/frontend/faq/index.blade.php ENDPATH**/ ?>