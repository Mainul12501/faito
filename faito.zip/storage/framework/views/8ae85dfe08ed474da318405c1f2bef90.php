<div class="right-header">
    <nav>
        <ul>
            <li>
                <a class="" href="<?php echo e(route('frontend.home')); ?>">
                    <?php echo e(trans('frontend.menu.home')); ?>

                </a>
            </li>
            <li class="have-child">
                <a class="" href="#" class=""><?php echo e(trans('frontend.menu.story')); ?></a>
                <ul>
                    <li>
                        <a class=""
                           href="<?php echo e(route('frontend.faitology')); ?>">
                            <?php echo e(trans('frontend.story_dropdown.faitology')); ?>

                        </a>
                    </li>
                    <li>
                        <a class=""
                           href="<?php echo e(route('frontend.faitotech')); ?>">
                            <?php echo e(trans('frontend.story_dropdown.faitotech')); ?>

                        </a>
                    </li>
                    <li>
                        <a class=""
                           href="<?php echo e(route('frontend.brembology')); ?>">
                            <?php echo e(trans('frontend.story_dropdown.brembology')); ?>

                        </a>
                    </li>
                    <li>
                        <a class=""
                           href="<?php echo e(route('frontend.testimonial')); ?>">
                            <?php echo e(trans('frontend.story_dropdown.testimonial')); ?>

                        </a>
                    </li>
                    <li>
                        <a class=""
                           href="<?php echo e(route('frontend.blog')); ?>">
                            <?php echo e(trans('frontend.story_dropdown.news')); ?>

                        </a>
                    </li>
                </ul>
            </li>
            <li class="have-child">
                <a class="" href="#" class=""><?php echo e(trans('frontend.menu.product')); ?></a>
                <ul>
                    <?php $__currentLoopData = $partsParentBrands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partsParentBrand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <a class=""
                               href="<?php echo e(route('frontend.product', ['brand_id' => $partsParentBrand->id, 'name' => $partsParentBrand->name])); ?>">
                                <?php echo e($partsParentBrand->name); ?>

                            </a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </li>
            <li>
                <a class="" href="<?php echo e(route('frontend.contact')); ?>">
                    <?php echo e(trans('frontend.menu.contact')); ?>

                </a>
            </li>
        </ul>
    </nav>
    <div class="box-lang">
        <span onclick="changeLang('en')" class="<?php echo e(Session::has('locale') && Session::get('locale') == 'en' ? 'active' : ''); ?>">EN</span>
        <span onclick="changeLang('bn')" class="<?php echo e(Session::has('locale') && Session::get('locale') == 'bn' ? 'active' : ''); ?>">BN</span>
    </div>
    <div class="box-search">
        <span class="icon-search"><img src="<?php echo e(asset('/')); ?>frontend/assets/images/material/ic-search.png" alt=""></span>
        <span class="icon-search black"><img src="<?php echo e(asset('/')); ?>frontend/assets/images/material/ic-search-bl.png" alt=""></span>
        <div class="search-box">

        </div>
    </div>
</div>
<?php /**PATH D:\Works\laravel\faito_app_updated_09022024\faito_app\resources\views/frontend/includes/right-header.blade.php ENDPATH**/ ?>