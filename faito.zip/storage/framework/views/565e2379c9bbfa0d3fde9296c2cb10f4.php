<?php $__env->startSection('body'); ?>
    <section class="banner-landing">
        <figure>
            <img src="<?php echo e(asset('/')); ?>frontend/assets/contents/aDjPKRIUf5.png" alt="">
        </figure>
        <div class="text-absolute">
            <h2><?php echo e($brand->name ?? 'Brand Name'); ?></h2>
            <span><img src="<?php echo e(asset('/')); ?>frontend/assets/images/material/shape-img-abs-red.png" alt=""></span>
        </div>
        <span class="shape-banner"><img src="<?php echo e(asset('/')); ?>frontend/assets/images/material/shape-banner-red.png" alt=""></span>
    </section>


    <section class="content-landing testi">
        <div class="wrapper">
            <div class="box-grid">
                <?php if(!empty($bikeModels)): ?>
                    <?php $__currentLoopData = $bikeModels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bikeModel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('frontend.product-search', ['title' => $bikeModel->model_name])); ?>" class="box big">
                            <figure>
                                <img src="<?php echo e(asset(!empty($bikeModel->image) ? $bikeModel->image : 'admin/no-img/no-image.png')); ?>" alt="model name" />
                                <figcaption>
                                    <h5><?php echo e($bikeModel->model_name); ?></h5>
                                    <span>View All</span>
                                </figcaption>
                            </figure>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\wamp64\www\faito\resources\views/frontend/product/bike.blade.php ENDPATH**/ ?>