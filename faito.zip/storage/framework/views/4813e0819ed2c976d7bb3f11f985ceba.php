<?php $__env->startSection('title', 'Site Settings'); ?>

<?php $__env->startSection('body'); ?>
    <div class="row mt-5">
        <div class="col-md-12 mx-auto">
            <div class="card">
                <div class="card-header bg-light">
                    <h3>Site Settings</h3>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(isset($siteSettings) ? route('admin.site-settings.update', $siteSettings->id) : route('admin.site-settings.store')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php if(isset($siteSettings)): ?>
                            <?php echo method_field('put'); ?>
                        <?php endif; ?>
                        <div class="row mt-5">
                            <div class="col-md-3">
                                <label for="" class="">Name</label>
                                <div class="">
                                    <input type="text" name="name" class="form-control" value="<?php echo e(isset($siteSettings) ? $siteSettings->name : old('name')); ?>" placeholder="Name" />
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <label for="">Title</label>
                                <div class="">
                                    <input type="text" name="title" class="form-control" value="<?php echo e(isset($siteSettings) ? $siteSettings->title : old('title')); ?>" placeholder="Site Title" />
                                    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <label for="">Email</label>
                                <div>
                                    <input type="email" name="email" class="form-control" value="<?php echo e(isset($siteSettings) ? $siteSettings->email : old('email')); ?>" placeholder="Email" />
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <label for="">Helpline Number</label>
                                <div>
                                    <input type="text" name="helpline_number" class="form-control" value="<?php echo e(isset($siteSettings) ? $siteSettings->helpline_number : old('helpline_number')); ?>" placeholder="Helpline Number" />
                                    <?php $__errorArgs = ['helpline_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>

                        <div class="row mt-5">
                            <label for="">Description</label>
                            <div id="">
                                <textarea name="description" class="form-control ckeditor"  placeholder="Site Description"><?php echo e(isset($siteSettings) ? $siteSettings->description : old('description')); ?></textarea>
                                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row mt-5">
                            <label for="">Default SEO Header</label>
                            <div id="">
                                <textarea name="default_seo_header" class="form-control ckeditor" placeholder="Default SEO Header"><?php echo e(isset($siteSettings) ? $siteSettings->default_seo_header : old('default_seo_header')); ?></textarea>
                                <?php $__errorArgs = ['default_seo_header'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row mt-5">
                            <label for="">Default SEO Footer</label>
                            <div id="">
                                <textarea name="default_seo_footer" class="form-control ckeditor" placeholder="Default SEO Footer"><?php echo e(isset($siteSettings) ? $siteSettings->default_seo_footer : old('default_seo_footer')); ?></textarea>
                                <?php $__errorArgs = ['default_seo_footer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row mt-5">
                            <div class="col-md-4">
                                <label for="">Menu Logo</label>
                                <div>
                                    <input type="file" name="menu_logo" class="form-control img-file" accept="image/*" />
                                    <img src="<?php echo e(asset(isset($siteSettings) ? $siteSettings->menu_logo : '')); ?>" alt="" style="height: 60px; margin-top: 10px;" id="menu_logo" />
                                </div>
                            </div>
                            <div class="col-md-4">
                                <label for="">Footer Logo</label>
                                <div>
                                    <input type="file" name="footer_logo" class="form-control img-file" accept="image/*" />
                                    <img src="<?php echo e(asset(isset($siteSettings) ? $siteSettings->footer_logo : '')); ?>" alt="" style="height: 60px; margin-top: 10px;" id="footer_logo" />
                                </div>
                            </div>
                            <div class="col-md-4">
                                <label for="">Favicon</label>
                                <div>
                                    <input type="file" name="favicon" class="form-control img-file" accept="image/*" />
                                    <img src="<?php echo e(asset(isset($siteSettings) ? $siteSettings->favicon : '')); ?>" alt="" style="height: 20px; margin-top: 10px;" id="favicon" />
                                </div>
                            </div>
                        </div>

                        <div class="row mt-5">
                            <div class="col-md-3">
                                <label for="">Instagram Link</label>
                                <div>
                                    <input type="text" name="insta_link" class="form-control" value="<?php echo e(isset($siteSettings) ? $siteSettings->insta_link : old('insta_link')); ?>" placeholder="Instagram Link" />
                                    <?php $__errorArgs = ['insta_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <label for="">Facebook Link</label>
                                <div>
                                    <input type="text" name="fb_link" class="form-control" value="<?php echo e(isset($siteSettings) ? $siteSettings->fb_link : old('fb_link')); ?>" placeholder="Facebook Link" />
                                    <?php $__errorArgs = ['fb_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <label for="">Youtube Link</label>
                                <div>
                                    <input type="text" name="youtube_link" class="form-control" value="<?php echo e(isset($siteSettings) ? $siteSettings->youtube_link : old('youtube_link')); ?>" placeholder="Youtube Link" />
                                    <?php $__errorArgs = ['youtube_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <label for="">Tiktok Link</label>
                                <div>
                                    <input type="text" name="tiktok_link" class="form-control" value="<?php echo e(isset($siteSettings) ? $siteSettings->tiktok_link : old('tiktok_link')); ?>" placeholder="Tiktok Link" />
                                    <?php $__errorArgs = ['tiktok_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>

                        <div class="row mt-5">
                            <label for="" class="col-md-4"></label>
                            <div class="col-md-6">
                                <input type="submit" class="btn btn-success" value="<?php echo e(isset($siteSettings) ? 'Update' : 'Create'); ?> Site Setting">
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        $(document).ready(function() {
            $('.img-file').change(function() {
                var idName = $(this).attr('name');
                var imgURL = URL.createObjectURL(event.target.files[0]);
                $('#'+idName).attr('src', imgURL).css({
                    height: 60+'px',
                    width: 80+'px',
                    marginTop: '5px'
                });
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Works\project outline\faito_appkk\faito_app\resources\views/backend/additional-features/site-settings/index.blade.php ENDPATH**/ ?>