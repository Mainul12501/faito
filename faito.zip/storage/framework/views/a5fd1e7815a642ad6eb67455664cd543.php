<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('body'); ?>
    <section class="content-landing detail">
        <div class="wrapper">
            <div class="breadcrumb">
                <ul>
                    <li><a href="<?php echo e(route('frontend.home')); ?>">Home</a> </li>
                    <li><a href="<?php echo e(route('frontend.product', ['brand_id' => $product->partsBrandCategory->partsParentBrand->id, 'name' => str_replace(' ', '-', $product->partsBrandCategory->partsParentBrand->name)])); ?>"><?php echo e($product->partsBrandCategory->partsParentBrand->name ?? ''); ?></a> </li>
                    <?php if(!empty($product->partsBrandCategory->partsBrandCategory)): ?>
                        <li><a href="<?php echo e(route('frontend.sub-cat', ['parts_parent_brand_category_id' => $product->partsBrandCategory->partsBrandCategory->id, 'name' => str_replace(' ', '-', $product->partsBrandCategory->partsBrandCategory->name) ])); ?>"><?php echo e($product->partsBrandCategory->partsBrandCategory->name); ?></a></li>
                    <?php endif; ?>
                    <li><a href="<?php echo e(route('frontend.sub-cat', ['parts_parent_brand_category_id' => $product->partsBrandCategory->id, 'name' => str_replace(' ', '-', $product->partsBrandCategory->name) ])); ?>"><?php echo e($product->partsBrandCategory->name ?? ''); ?></a></li>
                    <li><?php echo e($product->title ?? ''); ?></li>
                </ul>
            </div>
            <div class="detail-product">
                <div class="left-box">
                    <div class="slider-big">
                        <?php if(!empty($product->sub_images)): ?>
                            <?php $__currentLoopData = json_decode($product->sub_images); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subImage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="list">
                                    <figure><img src="<?php echo e(asset(isset($subImage) ? $subImage : 'frontend/assets/contents/ouPkud6jhV.png')); ?>" alt="" style="height: 480px"></figure>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <div class="list">
                                <figure><img src="<?php echo e(asset(!empty($product->main_image) ? $product->main_image : 'frontend/assets/contents/ouPkud6jhV.png')); ?>" alt=""></figure>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="slider-thumbnail">
                        <?php if(!empty($product->sub_images)): ?>
                            <?php $__currentLoopData = json_decode($product->sub_images); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subImage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="list">
                                    <figure><img src="<?php echo e(asset(!empty($subImage) ? $subImage : 'frontend/assets/contents/ouPkud6jhV.png')); ?>" alt="" ></figure>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <div class="list">
                                <figure><img src="<?php echo e(asset(!empty($product->main_image) ? $product->main_image : 'frontend/assets/contents/ouPkud6jhV.png')); ?>" alt="" ></figure>
                            </div>`
                        <?php endif; ?>
                    </div>
                </div>
                <div class="right-box">
                    <div class="title-product">
                        <span class="line-text"></span>
                        <small><?php echo e($product->sub_title ?? ''); ?></small>
                        <h1><?php echo e($product->title ?? ''); ?></h1>
                        
                        <p style="font-size: 14pt; line-height: 107%; font-family: arial, helvetica, sans-serif; text-align: justify"><?php echo $product->short_description; ?></p>
                        <div class="sharethis-inline-share-buttons"></div>
                    </div>
                    <!-- <hr>
                    <div class="box-information text-content">
                      <h5>Information</h5>

                    </div> -->
                    <hr>
                    <div class="marketplace">
                        <h5>Buy at Market Place</h5>
                        <?php if(!empty($product->marketVerdors)): ?>
                            <?php $__currentLoopData = $product->marketVerdors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marketVerdor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e($marketVerdor->pivot->link); ?>" target="_blank" rel="nofollow"><img src="<?php echo e(asset(!empty($marketVerdor->logo) ? $marketVerdor->logo : 'frontend/assets/images/content/ecom-1.png')); ?>" alt="" style="height: 32px" /></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        
                        
                        
                    </div>
                </div>
            </div>
            <div class="wrap-tab">
                <span class="sub">More Information</span>
                <div class="wrap-overflow">
                    <div class="box-tabing information">
                        <div class="head-tab">
                            <ul>
                                <li><a href="#desc">Description</a></li>
                                <li><a href="#feat">Features</a></li>
                            </ul>
                        </div>
                        <div class="content-tab text-content" id="desc">
                            <p><span class="HwtZe" lang="en"><span class="jCAhz ChMk0b"><span class="ryNqvb"><?php echo $product->long_description; ?></span></span></span></p>
                            <p>&nbsp;</p>
                        </div>
                        <div class="content-tab text-content" id="feat">
                            <?php echo $product->features; ?>

                        </div>
                    </div>
                </div>
            </div>
            <div class="wrap-tab">
                <span class="sub">Available For</span>
                <div class="wrap-overflow">
                    <div class="box-tabing merk blue overflow">
                        <div class="head-tab">
                            <ul>
                                <?php $__currentLoopData = $bikeBrandGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $bikeBrandGroup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><a href="#tabId<?php echo e($key); ?>"><?php echo e($bikeBrandGroup[0]->custom_brand_name); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </ul>
                        </div>
                        <?php $__currentLoopData = $bikeBrandGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $bikeBrandGroupContent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="content-tab text-content" id="tabId<?php echo e($index); ?>">
                                <div class="table">
                                    <table>
                                        <thead>
                                        <tr>
                                            <th>Motor Type</th>
                                            <th>Year</th>
                                            <th>Engine</th>
                                            <th>Size</th>
                                            <th>Variant</th>
                                            <th>SKU</th>
                                            <th>Action</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php if(!empty($bikeBrandGroupContent)): ?>
                                            <?php $__currentLoopData = $bikeBrandGroupContent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bd => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($value->model_name ?? ''); ?></td>
                                                    <td><?php echo e($value->bikeYearVersion->name ?? ''); ?></td>
                                                    <td><?php echo e($value->bikeEngineSize->name ?? ''); ?></td>
                                                    <td><?php echo e($value->size ?? ''); ?></td>
                                                    <td><?php echo e($value->variant ?? ''); ?></td>
                                                    <td><?php echo e($value->sku ?? ''); ?></td>
                                                    <td>
                                                        <a href="#">View Detail</a>
                                                        <div class="data-popup">
                                                            <div class="img">
                                                                
                                                                <?php echo e(asset($value->image)); ?>

                                                            </div>
                                                            <div class="text">
                                                                <h4><?php echo e($product->title); ?></h4>
                                                                <span class="spek"><?php echo e($bikeBrandGroupContent[0]->custom_brand_name ?? ''); ?> <?php echo e($value->model_name ?? ''); ?> - Size : <?php echo e($value->size ?? ''); ?>  - Variant : <?php echo e($value->variant ?? ''); ?> -  SKU : <?php echo e($value->sku ?? ''); ?></span>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>

            <div class="related-product">
                <span class="sub">Related Product</span>
                <div class="listing-wrap product no-margin">
                    <?php $__currentLoopData = $relatedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relatedProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('frontend.product-details', ['id' => $relatedProduct->id, 'slug' => str_replace(' ','-', $relatedProduct->title)])); ?>" class="list">
                            <figure>
                                <img src="<?php echo e(asset(!empty($relatedProduct->main_image) ? $relatedProduct->main_image : 'frontend/assets/contents/ouPkud6jhV.png')); ?>" alt="">
                            </figure>
                            <span class="name-sparepart"><?php echo e($relatedProduct->partsBrandCategory->name ?? ''); ?></span>
                            <h5><?php echo e($relatedProduct->title); ?></h5>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </section>

    <div class="wrap-pop" id="product">
        <div class="pop-inner">
            <div class="overlay-pop"></div>
            <div class="box-pop">
                <div class="content-pop">
                    <a href="javascript: closePopup('product')" class="close"></a>
                    <div class="img">
                        <img src="#" alt="">
                    </div>
                    <div class="text">

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script type="text/javascript" src="https://platform-api.sharethis.com/js/sharethis.js#property=65c6298ad77abd0019f02da1&product=inline-share-buttons&source=platform" async="async"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mainul Islam\Downloads\Compressed\temp\faito-app\faito_app\resources\views/frontend/product/product-details.blade.php ENDPATH**/ ?>