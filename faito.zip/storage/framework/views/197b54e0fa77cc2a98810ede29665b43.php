<div class="popup-search" id="popupsearch">
    <div class="close-popup-search">
        <span></span><span></span>
    </div>
    <div class="box-inner-search normal-search active">
        <form action="<?php echo e(route('frontend.product-search')); ?>">
            <input type="text" name="title" placeholder="Search Our Product">
            <a class="link-yellow btn-adv-search">Advance Search</a>
        </form>
    </div>
    <div class="box-inner-search advance-search">
        <h3>Advance Search</h3>
        <div class="form">
            <form action="<?php echo e(route('frontend.product-search')); ?>">
                <div class="row">
                    <div class="col half">
                        <div class="row">
                            <div class="col half">
                                <select name="brand" id="brand">
                                    <option value="">Brand</option>
                                    <?php if(!empty($bikeBrands)): ?>
                                        <?php $__currentLoopData = $bikeBrands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bikeBrand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($bikeBrand->id); ?>"><?php echo e($bikeBrand->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>
                            </div>
                            <div class="col half">
                                <select name="motortype" id="motortype">
                                    <option value="">Motor Type</option>
                                    <?php if(!empty($motorTypes)): ?>
                                        <?php $__currentLoopData = $motorTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $motorType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($motorType->id); ?>"><?php echo e($motorType->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="col half">
                        <div class="row">
                            <div class="col half">
                                <select name="enginesize" id="enginesize">
                                    <option value="">Engine Size</option>
                                    <?php if(!empty($engineSizes)): ?>
                                        <?php $__currentLoopData = $engineSizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $engineSize): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($engineSize->id); ?>"><?php echo e($engineSize->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>
                            </div>
                            <div class="col half">
                                <select name="year" id="year">
                                    <option value="">Year</option>
                                    <?php if(!empty($bikeYearVersions)): ?>
                                        <?php $__currentLoopData = $bikeYearVersions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bikeYearVersion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($bikeYearVersion->id); ?>"><?php echo e($bikeYearVersion->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col half">
                        <select name="motor" id="motor">
                            <option value="">Motorcycle</option>
                            <?php if(!empty($motorBikes)): ?>
                                <?php $__currentLoopData = $motorBikes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $motorBike): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($motorBike->id); ?>"><?php echo e($motorBike->model_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                    </div>
                    <div class="col half">
                        <select name="category" id="category">
                            <option value="">Category</option>
                            <?php if(!empty($partsCategories)): ?>
                                <?php $__currentLoopData = $partsCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partsCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($partsCategory->id); ?>"><?php echo e($partsCategory->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <br><br>
                        <input type="submit" value="Search Now" class="btn-yellow">
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php /**PATH H:\wamp64\www\faito\resources\views/frontend/includes/popupsearch.blade.php ENDPATH**/ ?>