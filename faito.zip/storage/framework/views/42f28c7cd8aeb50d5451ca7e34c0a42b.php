<?php $__env->startSection('title', 'Contacts'); ?>

<?php $__env->startSection('body'); ?>
    <div class="row mt-5">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header bg-light">
                    <h3>Manage Contacts</h3>
                    <ul class="nav nav-pills position-absolute me-5 mb-3" id="pills-tab" role="tablist" style="right: 0">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="pills-home-tab" data-bs-toggle="pill" data-bs-target="#pills-home" type="button" role="tab" aria-controls="pills-home" aria-selected="true">Regular</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="pills-profile-tab" data-bs-toggle="pill" data-bs-target="#pills-profile" type="button" role="tab" aria-controls="pills-profile" aria-selected="false">Reseller</button>
                        </li>
                    </ul>
                </div>
                <div class="card-body">
                    <div class="tab-content" id="pills-tabContent">
                        <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">
                            <div class="table-responsive export-table">
                                <table class="table" id="file-datatable">
                                    <thead>
                                    <th>#</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Mobile</th>
                                    <th>Bike Motor Type</th>
                                    <th>Message</th>
                                    <th>Status</th>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($contact->contact_type == 'regular'): ?>
                                            <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($contact->name); ?></td>
                                            <td><?php echo e($contact->email); ?></td>
                                            <td><?php echo e($contact->mobile); ?></td>
                                            <td><?php echo e($contact->bike_motor_type_id); ?></td>
                                            <td><?php echo e($contact->message); ?></td><td><?php echo e($contact->status == 1 ? 'Published' : 'Unpublished'); ?></td>
                                        </tr>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">
                            <div class="table-responsive export-table">
                                <table class="table" id="file-datatable">
                                    <thead>
                                    <th>#</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Mobile</th>
                                    <th>Workshop Info</th>
                                    <th>Workshop Outside Image</th>
                                    <th>Workshop Inside Image</th>
                                    <th>Workshop Selfie Image</th>
                                    <th>Status</th>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       <?php if($contact->contact_type == 'reseller'): ?>
                                           <tr>
                                               <td><?php echo e($loop->iteration); ?></td>
                                               <td><?php echo e($contact->name); ?></td>
                                               <td><?php echo e($contact->email); ?></td>
                                               <td><?php echo e($contact->mobile); ?></td>
                                               <td><?php echo e($contact->workshop_info); ?></td>
                                               <td><img src="<?php echo e(asset(!empty($contact->workshop_outside_image) ? $contact->workshop_outside_image : 'admin/no-img/no-image.jpeg')); ?>" alt="" style="height: 60px" /></td>
                                               <td><img src="<?php echo e(asset(!empty($contact->workshop_inside_image) ? $contact->workshop_inside_image : 'admin/no-img/no-image.jpeg')); ?>" alt="" style="height: 60px" /></td>
                                               <td><img src="<?php echo e(asset(!empty($contact->workshop_selfie_image) ? $contact->workshop_selfie_image : 'admin/no-img/no-image.jpeg')); ?>" alt="" style="height: 60px" /></td>
                                               <td><?php echo e($contact->status == 1 ? 'Published' : 'Unpublished'); ?></td>
                                           </tr>
                                       <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Works\laravel\faito_app_updated_09022024\faito_app\resources\views/backend/additional-features/contacts/index.blade.php ENDPATH**/ ?>