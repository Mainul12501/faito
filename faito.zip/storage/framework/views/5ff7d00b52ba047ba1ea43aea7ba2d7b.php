

<?php $__env->startSection('title', isset($blogCategory) ? 'Edit' : 'Create'.' Blog Category'); ?>

<?php $__env->startSection('body'); ?>
    <div class="row py-5">
        <div class="col-md-6 mx-auto">
            <div class="card">
                <div class="card-header bg-light">
                    <h3><?php echo e(isset($blogCategory) ? 'Edit' : 'Create'); ?> Blog Category</h3>
                    <a href="<?php echo e(route('admin.blog-categories.index')); ?>" class="btn btn-success btn-sm position-absolute me-5" style="right: 0"><i class="fa fa-sliders"></i></a>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(isset($blogCategory) ? route('admin.blog-categories.update', $blogCategory->id) : route('admin.blog-categories.store')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php if(isset($blogCategory)): ?>
                            <?php echo method_field('put'); ?>
                        <?php endif; ?>
                        <div class="row mt-4">
                            <label for="" class="col-md-4">Category Name*</label>
                            <div class="col-md-8">
                                <input type="text" name="name" class="form-control" placeholder="Category Name" value="<?php echo e(isset($blogCategory) ? $blogCategory->name : ''); ?>" />
                            </div>
                        </div>
                        <div class="row mt-4">
                            <label for="" class="col-md-4">Category Image</label>
                            <div class="col-md-8">
                                <input type="file" name="image" class="form-control" accept="image/*" />
                                <?php if(isset($blogCategory)): ?>
                                    <img src="<?php echo e(asset($blogCategory->image)); ?>" alt="" style="height: 80px" />
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="row mt-4">
                            <label for="" class="col-md-4">Category Status</label>
                            <div class="col-md-8">
                                <div class="material-switch">
                                    <input id="someSwitchOptionLight" name="status" type="checkbox" <?php echo e(isset($blogCategory) && $blogCategory->status == 0 ? '' : 'checked'); ?> />
                                    <label for="someSwitchOptionLight" class="label-light"></label>
                                </div>
                            </div>
                        </div>
                        <div class="row mt-4">
                            <label for="" class="col-md-4"></label>
                            <div class="col-md-8">
                                <input type="submit" class="btn btn-success" value="<?php echo e(isset($blogCategory) ? 'Update' : 'Create'); ?> Blog Category">
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laravel\faito_app\resources\views/backend/blog-management/blog-categories/form.blade.php ENDPATH**/ ?>