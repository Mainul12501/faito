

<?php $__env->startSection('title', isset($partsBrandCategory) ? 'Edit' : 'Create'.' Parts Brand Category'); ?>

<?php $__env->startSection('body'); ?>
    <div class="row mt-5">
        <div class="col-md-9 mx-auto">
            <div class="card">
                <div class="card-header bg-light">
                    <h3><?php echo e(isset($partsBrandCategory) ? 'update' : 'Create'); ?> Parts Brand Category</h3>
                    <a href="<?php echo e(route('admin.parts-brand-categories.index')); ?>" class="btn btn-success btn-sm position-absolute me-5" style="right: 0"><i class="fa fa-sliders"></i></a>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(isset($partsBrandCategory) ? route('admin.parts-brand-categories.update', $partsBrandCategory->id) : route('admin.parts-brand-categories.store')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php if(isset($partsBrandCategory)): ?>
                            <?php echo method_field('put'); ?>
                        <?php endif; ?>
                        <input type="hidden" name="parts_brand_category_id" value="<?php echo e(isset($partsBrandCategory) ? $partsBrandCategory->parts_brand_category_id : (isset($_GET['parts_brand_category_id']) ? $_GET['parts_brand_category_id'] :  0)); ?>" />
                        <div class="row mt-3">
                            <label for="" class="col-md-3">Parts Parent Brand</label>
                            <div class="col-md-9">
                                <select name="parts_parent_brand_id" class=" form-control " data-toggle="select" data-placeholder="Choose ...">
                                    <option value="">Select a Parts Parent Brand</option>
                                    <?php $__currentLoopData = $partsParentBrands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partsParentBrand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($partsParentBrand->id); ?>" <?php echo e($errors->any() ? (old('parts_parent_brand_id')) :(isset($partsBrandCategory) && $partsBrandCategory->parts_parent_brand_id== $partsParentBrand->id ? 'selected' : '')); ?>> <?php echo e($partsParentBrand->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <?php $__errorArgs = ['parts_parent_brand_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($errors->first('parts_parent_brand_id')); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="row mt-3">
                            <label for="" class="col-md-3">Name</label>
                            <div class="col-md-9">
                                <input type="text" name="name" class="form-control" value="<?php echo e(isset($partsBrandCategory) ? $partsBrandCategory->name : ''); ?>" placeholder="Bike Motor Type Name" />
                            </div>
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($errors->first('name')); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="row mt-3">
                            <div class="col-12">
                                <span class="">Description</span>
                                <div class="">
                                    <textarea type="text" name="description" class="form-control ckeditor" placeholder="Bike Motor Type Other Info" id="" cols="30" rows="5"><?php echo e(isset($partsBrandCategory) ? $partsBrandCategory->description : ''); ?></textarea>
                                </div>
                            </div>

                        </div>
                        <div class="row mt-3">
                            <label for="" class="col-md-3">Image</label>
                            <div class="col-md-9">
                                <input type="file" name="image" class="form-control" placeholder="Bike Motor Type Image" accept="" id="imagez" />
                                <?php if(isset($partsBrandCategory)): ?>
                                    <img src="<?php echo e(asset($partsBrandCategory->image)); ?>" alt="" style="height: 80px">
                                <?php endif; ?>
                                <span class="text-danger">Min resolution 600 * 350 px</span>
                            </div>
                            <div class="col-md-3 mt-2">
                                <div>
                                    <img src="" id="imagePreview" alt="">
                                </div>
                            </div>
                        </div>
                        <div class="row mt-3">
                            <label for="" class="col-md-3">Status</label>
                            <div class="col-md-9">
                                <div class="material-switch">
                                    <input id="someSwitchOptionLight" name="status" type="checkbox" <?php echo e(isset($partsBrandCategory) && $partsBrandCategory->status == 0 ? '' : 'checked'); ?> />
                                    <label for="someSwitchOptionLight" class="label-light"></label>
                                </div>
                            </div>
                        </div>
                        <div class="row mt-3">
                            <label for="" class="col-md-3"></label>
                            <div class="col-md-9">
                                <input type="submit" class="btn btn-success" value="<?php echo e(isset($partsBrandCategory) ? 'update' : 'Create'); ?> Parts Brand Category">
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    image<script>
        $(document).ready(function() {
            $('#imagez').change(function() {
                var imgURL = URL.createObjectURL(event.target.files[0]);
                $('#imagePreview').attr('src', imgURL).css({
                    height: 150+'px',
                    width: 150+'px',
                    marginTop: '5px'
                });
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/twowheel/faito.twowheelersbd.com/resources/views/backend/parts-management/parts-brand-category/create.blade.php ENDPATH**/ ?>