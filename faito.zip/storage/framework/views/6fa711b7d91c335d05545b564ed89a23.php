<?php $__env->startSection('body'); ?>
    <section class="banner-home">
        <span class="dots-abs"><img src="<?php echo e(asset('/')); ?>frontend/assets/images/material/dots-square.png" alt=""></span>
        <div class="slider-home">
            <?php $__currentLoopData = $homePageSliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $homePageSlider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="list-slider">
                <figure>
                    <?php if($homePageSlider->slider_file_type == 'image'): ?>
                        <img
                        src="#"
                        data-img-large="<?php echo e(asset(!empty($homePageSlider->file) ? $homePageSlider->file : 'frontend/assets/contents/ZElyCoBksg.png' )); ?>"
                        data-img-medium="<?php echo e(asset(!empty($homePageSlider->file) ? $homePageSlider->file : 'frontend/assets/contents/KKpBIdJBF7.png' )); ?>"
                        data-img-small="<?php echo e(asset(!empty($homePageSlider->file) ? $homePageSlider->file : 'frontend/assets/contents/Qy72pR5HJ3.png' )); ?>"
                        alt="" />
                    <?php elseif($homePageSlider->slider_file_type == 'video'): ?>
                        <div class="video-home">
                            <video  autoplay="" loop="" control="" muted="">
                                <source src="<?php echo e(asset(!empty($homePageSlider->file_url) ? $homePageSlider->file_url : asset($homePageSlider->file))); ?>" type="video/mp4">
                                Your browser does not support the video tag.
                            </video>
                        </div>
                    <?php endif; ?>
                </figure>

                    <?php if($loop->first): ?>
                        <a href="<?php echo e(route('frontend.faitology')); ?>" class="caption">
                            <h2>FAITO <b></b></h2>
                            <p>OUR INNOVATION FOR THE COMFORT</p>
                            <p>AND PERFORMANCE OF YOUR MOTORBIKE</p>
                            <div class="btn-arr-home"><span><?php echo e(trans('frontend.common.read_more')); ?></span></div>
                        </a>
                    <?php endif; ?>

            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="medsos-banner">
            <?php $__currentLoopData = $siteSettings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siteSetting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e($siteSetting->fb_link ?? ''); ?>/" rel="nofollow" target="_blank"><img src="<?php echo e(asset('/')); ?>frontend/assets/contents/DL94PSMnkG.png" alt=""></a>
                <a href="<?php echo e($siteSetting->tiktok_link ?? ''); ?>" rel="nofollow" target="_blank"><img src="<?php echo e(asset('/')); ?>frontend/assets/contents/G6cXnP7XQs.png" alt=""></a>
                <a href="<?php echo e($siteSetting->insta_link ?? ''); ?>" rel="nofollow" target="_blank"><img src="<?php echo e(asset('/')); ?>frontend/assets/contents/8kSM0H9toL.png" alt=""></a>
                <a href="<?php echo e($siteSetting->youtube_link ?? ''); ?>" rel="nofollow" target="_blank"><img src="<?php echo e(asset('/')); ?>frontend/assets/contents/lLW3VdDELH.png" alt=""></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <span class="shape-banner"><img src="<?php echo e(asset('/')); ?>frontend/assets/images/material/shape-banner.png" alt=""></span>
    </section>

    <section class="about home">
        <div class="trigger-about"></div>
        <span class="img-abs"><img src="<?php echo e(asset('/')); ?>frontend/assets/images/material/shape-about-1.png" alt=""></span>
        <span class="img-abs-2"><img src="<?php echo e(asset('/')); ?>frontend/assets/images/material/shape-about-2.png" alt=""></span>
        <div class="wrapper">
            <div class="wrap-flex-home">
                <a href="<?php echo e(route('frontend.faitology')); ?>" class="img anim-from-bottom" trigger-anim=".trigger-about" delay="0.5">
                    <figure>
                        <img src="<?php echo e(asset('/')); ?>frontend/assets/contents/ouPkud6jhV.png" alt="">
                    </figure>
                    <span class="abs-img"><img src="<?php echo e(asset('/')); ?>frontend/assets/images/material/shape-img-abs.png" alt=""></span>
                </a>
                <a href="<?php echo e(route('frontend.faitology')); ?>" class="text anim-from-bottom" trigger-anim=".trigger-about" delay="0.8">
                    <small class="text-line"><?php echo e(trans('frontend.home.motto')); ?></small>
                    <span class="number-big"><img src="<?php echo e(asset('/')); ?>frontend/assets/contents/index.html" alt=""></span>
                    <h1><?php echo e(trans('frontend.home.motto_title')); ?></h1>
                    <p><?php echo e(trans('frontend.home.motto_sub_title')); ?></p>
                    <p><?php echo e(trans('frontend.home.motto_des')); ?></p>
                    <p>&nbsp;</p>
                    <span class="btn-arr"><?php echo e(trans('frontend.common.read_more')); ?></span>
                </a>
            </div>
        </div>
    </section>

    <section class="about-2 home">
        <div class="trigger-about-2"></div>
        <span class="img-abs"><img src="<?php echo e(asset('/')); ?>frontend/assets/images/material/path-about-faito.png" alt=""></span>
        <span class="img-abs-2"><img src="<?php echo e(asset('/')); ?>frontend/assets/images/material/dots-about-faito.png" alt=""></span>
        <div class="wrap-flex-home sec-2">
            <a href="<?php echo e(route('frontend.faitotech')); ?>" class="text anim-from-bottom" trigger-anim=".trigger-about-2" delay="0.6">
                <span class="number-big"><img src="<?php echo e(asset('/')); ?>frontend/assets/contents/index.html" alt=""></span>
                <small class="text-line"><?php echo e(trans('frontend.home.faitotech')); ?></small>
                <h1><?php echo e(trans('frontend.home.faitotech_title')); ?></h1>
                <p><?php echo e(trans('frontend.home.faitotech_des')); ?></p>
                <p>&nbsp;</p>
                <span class="btn-arr"><?php echo e(trans('frontend.common.read_more')); ?></span>
            </a>
            <a href="<?php echo e(route('frontend.faitotech')); ?>" class="img anim-from-bottom" trigger-anim=".trigger-about-2" delay="0.3">
                <figure>
                    <img src="<?php echo e(asset('/')); ?>frontend/assets/contents/4DMaMQm0mL.png" alt="">
                </figure>
            </a>
        </div>
    </section>

    <section class="product home">
        <div class="trigger-product"></div>
        <span class="bg"><img src="<?php echo e(asset('/')); ?>frontend/assets/contents/tB8tSyuiP2.png" alt=""></span>
        <div class="wrapper">
            <div class="text-tittle">
                <span class="number-big"><img src="<?php echo e(asset('/')); ?>frontend/assets/contents/index.html" alt=""></span>
                <small class="text-line vertical anim-from-bottom" trigger-anim=".trigger-product" delay="0.3"><?php echo e(trans('frontend.home.faito_products')); ?></small>
                <h1 class="anim-from-bottom" trigger-anim=".trigger-product" delay="0.5"><?php echo e(trans('frontend.home.faito_products_title')); ?></h1>
            </div>
            <div class="box-slider-product-home anim-from-bottom" trigger-anim=".trigger-product" delay="0.7">
                <div class="slider-product-home">
                    <?php $__currentLoopData = $bikeMotorTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bikeMotorType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('frontend.bike-brands', ['bike_motor_type_id' => $bikeMotorType->id, 'bike_brand_name' => str_replace(' ', '-', $bikeMotorType->name)])); ?>" class="list">
                            <figure>
                                <img src="<?php echo e(asset(!empty($bikeMotorType->image) ? $bikeMotorType->image : 'frontend/assets/contents/cn62IBPq8M.png')); ?>" alt="Matic">
                                <figcaption>
                                    <h5><?php echo e($bikeMotorType->name ?? ''); ?></h5>
                                </figcaption>
                            </figure>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="indicator-slider">
                    <span class="number-slider">
                      <span class="number-in-slider">01</span> of <span class="count-in-slider">5</span>
                    </span>
                    <div class="line-indicator-slider">
                        <span></span>
                    </div>
                    <a href="#" class="btn-arr"><?php echo e(trans('frontend.common.view_all_product')); ?></a>
                </div>
            </div>
        </div>
    </section>

    <section class="news home">
        <div class="trigger-news"></div>
        <div class="wrapper">
            <div class="title-news anim-from-bottom" trigger-anim=".trigger-news" delay="0.3">
                <h4><?php echo e(trans('frontend.home.latest_update')); ?></h4>
                <a href="<?php echo e(route('frontend.blog')); ?>" class="btn-arr"><?php echo e(trans('frontend.common.view_all')); ?></a>
            </div>
            <div class="wrap-box-news">
                <a href="<?php echo e(route('frontend.blog-details', ['blog_id' => $blogs[0]->id, 'titile' => str_replace(' ', '-', $blogs[0]->title)])); ?>" class="big-img anim-from-bottom" trigger-anim=".trigger-news" delay="0.6">
                    <span class="dots-abs"><img src="<?php echo e(asset('/')); ?>frontend/assets/images/material/dots-square-small.png" alt=""></span>
                    <img src="<?php echo e(asset(!empty($blogs[0]->image) ? $blogs[0]->image : 'frontend/assets/contents/enbXNhcBFb.png')); ?>" alt="">
                    <figcaption>
                        <h5>
                            <?php echo e($blogs[0]->title ?? ''); ?>

                        </h5>
                        <div class="caption-small">
                            <span><?php echo e($blogs[0]->blogCategory->name ?? ''); ?></span>
                            <span class="date"><?php echo e($blogs[0]->created_at->format('d M Y') ?? ''); ?></span>
                        </div>
                    </figcaption>
                </a>
                <div class="right-list anim-from-bottom" trigger-anim=".trigger-news" delay="0.8">
                    <?php $__currentLoopData = $blogs->skip(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('frontend.blog-details', ['blog_id' => $blog->id, 'titile' => str_replace(' ', '-', $blog->title)])); ?>" class="list" style="width: 100%">
                            <figure>
                                <img src="<?php echo e(asset(!empty($blog->image) ? $blog->image : 'frontend/assets/contents/uyynP93oEV.jpg')); ?>" alt="" style="width: 227.19px; height: 140.19px" />
                            </figure>
                            <div class="text ms-6">
                                <p><?php echo e($blog->title ?? ''); ?></p>
                                <div class="caption-small">
                                    <span><?php echo e($blog->blogCategory->name ?? ''); ?></span>
                                    <span class="date"><?php echo e($blog->created_at->format('d M Y') ?? ''); ?></span>
                                </div>
                            </div>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\wamp64\www\faito\resources\views/frontend/home/index.blade.php ENDPATH**/ ?>