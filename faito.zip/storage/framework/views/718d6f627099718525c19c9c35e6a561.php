

<?php $__env->startSection('title', 'Create Parts Brand Category'); ?>

<?php $__env->startSection('body'); ?>
    <div class="row mt-5">
        <div class="col-md-6 mx-auto">
            <div class="card">
                <div class="card-header">
                    <h3><?php echo e(isset($partsBrandCategory) ? 'update' : 'Create'); ?>Parts Brand Category</h3>
                    <a href="<?php echo e(route('admin.parts-brand-categories.index')); ?>" class="btn btn-success btn-sm position-absolute me-5" style="right: 0"><i class="fa fa-sliders"></i></a>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(isset($partsBrandCategory) ? route('admin.parts-brand-categories.update', $partsBrandCategory->id) : route('admin.parts-brand-categories.store')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php if(isset($partsBrandCategory)): ?>
                            <?php echo method_field('put'); ?>
                        <?php endif; ?>

                        <div class="row mt-3">
                            <label for="" class="col-md-4">Parts Parent Brand</label>
                            <div class="col-md-8">
                                <select name="parts_parent_brand_id" class=" form-control " data-toggle="select" data-placeholder="Choose ...">
                                    <option value="">Select a Parts Parent Brand</option>
                                    <?php $__currentLoopData = $partsParentBrands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partsParentBrand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($partsParentBrand->id); ?>" <?php echo e($errors->any() ? (old('parts_parent_brand_id')) :(isset($partsBrandCategory) && $partsBrandCategory->parts_parent_brand_id== $partsParentBrand->id ? 'selected' : '')); ?>> <?php echo e($partsParentBrand->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <?php $__errorArgs = ['parts_parent_brand_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($errors->first('parts_parent_brand_id')); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="row mt-3">
                            <label for="" class="col-md-4">Name</label>
                            <div class="col-md-8">
                                <input type="text" name="name" class="form-control" value="<?php echo e(isset($partsBrandCategory) ? $partsBrandCategory->name : ''); ?>" placeholder="Bike Motor Type Name" />
                            </div>
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($errors->first('name')); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="row mt-3">
                            <label for="" class="col-md-4">Description</label>
                            <div class="col-md-8">
                                <textarea type="text" name="description" class="form-control ckeditor" placeholder="Bike Motor Type Other Info" id="" cols="30" rows="5"><?php echo e(isset($partsBrandCategory) ? $partsBrandCategory->description : ''); ?></textarea>
                            </div>
                        </div>
                        <div class="row mt-3">
                            <label for="" class="col-md-4">Image</label>
                            <div class="col-md-8">
                                <input type="file" name="image" class="form-control" placeholder="Bike Motor Type Image" accept="">
                                <?php if(isset($partsBrandCategory)): ?>
                                    <img src="<?php echo e(asset($partsBrandCategory->image)); ?>" alt="" style="height: 80px">
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="row mt-3">
                            <label for="" class="col-md-4">Status</label>
                            <div class="col-md-8">
                                <div class="material-switch">
                                    <input id="someSwitchOptionLight" name="status" type="checkbox" <?php echo e(isset($partsBrandCategory) && $partsBrandCategory->status == 0 ? '' : 'checked'); ?> />
                                    <label for="someSwitchOptionLight" class="label-light"></label>
                                </div>
                            </div>
                        </div>
                        <div class="row mt-3">
                            <label for="" class="col-md-4"></label>
                            <div class="col-md-8">
                                <input type="submit" class="btn btn-success" value="<?php echo e(isset($partsBrandCategory) ? 'update' : 'Create'); ?> Bike Motor Type">
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laravel\faito_app\resources\views/backend/parts-management/parts-brand-category/create.blade.php ENDPATH**/ ?>