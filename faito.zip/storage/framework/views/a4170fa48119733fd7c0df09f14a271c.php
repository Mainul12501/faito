<!doctype html>
<html lang="en" dir="ltr">
<head>

    <!-- META DATA -->
    <?php echo $__env->make('backend.includes.assets.meta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- TITLE -->
    <title>Faito - <?php echo $__env->yieldContent('title'); ?></title>

    <!-- FAVICON -->
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('/')); ?>backend/assets/images/brand/favicon.ico" />

    <?php echo $__env->make('backend.includes.assets.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>

<body class="ltr app sidebar-mini">

<!-- Switcher-->
<!-- Switcher -->
<?php echo $__env->make('backend.includes.switcher', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- End Switcher -->
<!-- Switcher-->

<!-- GLOBAL-LOADER -->
<div id="global-loader">
    <img src="<?php echo e(asset('/')); ?>backend/assets/images/loader.svg" class="loader-img" alt="Loader">
</div>
<!-- /GLOBAL-LOADER -->

<!-- PAGE -->
<div class="page">
    <div class="page-main">

        <!-- app-Header -->
        <?php echo $__env->make('backend.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- /app-Header -->

        <!--APP-SIDEBAR-->
        <?php echo $__env->make('backend.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!--/APP-SIDEBAR-->

        <!--app-content open-->
        <div class="app-content main-content mt-0">
            <div class="side-app">

                <!-- CONTAINER -->
                <div class="main-container container-fluid">

                    <?php echo $__env->yieldContent('body'); ?>

                </div>
            </div>
        </div>
        <!-- CONTAINER CLOSED -->
    </div>




    <?php echo $__env->make('backend.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</div>
<!-- page -->

<!-- BACK-TO-TOP -->
<a href="#top" id="back-to-top"><i class="fa fa-long-arrow-up"></i></a>

<?php echo $__env->make('backend.includes.assets.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html>
<?php /**PATH C:\Users\Mainul Islam\Downloads\Compressed\temp\faito-app\faito_app\resources\views/backend/master.blade.php ENDPATH**/ ?>