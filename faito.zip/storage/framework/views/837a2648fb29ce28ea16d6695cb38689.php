<?php echo e($slot); ?>

<?php /**PATH D:\Works\laravel\faito_app_updated_09022024\faito_app\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>