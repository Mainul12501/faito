<?php $__env->startSection('body'); ?>
    <section class="banner-landing">
        <figure>
            <img src="<?php echo e(asset('/')); ?>frontend/assets/contents/aDjPKRIUf5.png" alt="">
        </figure>
        <div class="text-absolute">
            <h2>Bebek</h2>
            <span><img src="<?php echo e(asset('/')); ?>frontend/assets/images/material/shape-img-abs.png" alt=""></span>
        </div>
        <span class="shape-banner"><img src="<?php echo e(asset('/')); ?>frontend/assets/images/material/shape-banner.png" alt=""></span>
    </section>


    <section class="content-landing testi">
        <div class="wrapper">
            <div class="box-grid">

                <a href="bebek/honda.html" class="box big">
                    <figure>
                        <img src="<?php echo e(asset('/')); ?>frontend/assets/contents/u8rnJMXkHM.png" alt="">
                        <figcaption>
                            <h5>Honda</h5>
                            <span>View All</span>
                        </figcaption>
                    </figure>
                </a>



                <a href="bebek/suzuki.html" class="box big">
                    <figure>
                        <img src="<?php echo e(asset('/')); ?>frontend/assets/contents/rAQyXvhSe7.png" alt="">
                        <figcaption>
                            <h5>Suzuki</h5>
                            <span>View All</span>
                        </figcaption>
                    </figure>
                </a>



                <a href="<?php echo e(route('frontend.bike')); ?>" class="box big">
                    <figure>
                        <img src="<?php echo e(asset('/')); ?>frontend/assets/contents/tJfOgJotg3.png" alt="">
                        <figcaption>
                            <h5>Yamaha</h5>
                            <span>View All</span>
                        </figcaption>
                    </figure>
                </a>


            </div>

        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Works\laravel\faito_app_updated_09022024\faito_app\resources\views/frontend/product/bike-brand.blade.php ENDPATH**/ ?>