<?php $__env->startSection('body'); ?>
    <section class="banner-landing">
        <figure>
            <img src="<?php echo e(asset('/')); ?>frontend/assets/contents/FFAgeh1hrx.png" alt="">
        </figure>
        <div class="text-absolute">
            <h2><?php echo e(trans('frontend.story.news.news')); ?></h2>
            <span><img src="<?php echo e(asset('/')); ?>frontend/assets/images/material/shape-img-abs.html" alt=""></span>
        </div>
        <span class="shape-banner"><img src="<?php echo e(asset('/')); ?>frontend/assets/images/material/shape-banner.html" alt=""></span>
    </section>

    <section class="content-landing">
        <div class="wrapper">
            <div class="middle detail">
                <div class="title-landing full">
                    <div class="title">
                        <span class="line-text"></span>
                        <small><?php echo e($blog->blogCategory->name ?? ''); ?></small>
                        <h3><?php echo e($blog->title ?? ''); ?> STEERING CONE MX-SERIES</h3>
                        <span class="date-detail"><?php echo e($blog->created_at->format('d M Y')); ?></span>
                    </div>
                </div>

                <div class="sharethis-inline-share-buttons"></div>

                <div class="images-detail">
                    <img src="<?php echo e(asset(!empty($blog->image) ? $blog->image : 'frontend/assets/contents/enbXNhcBFb.png')); ?>" alt="">
                </div>
                <div class="text-content">
                    <p><?php echo $blog->content ?? ''; ?></p>
                </div>
                <div class="related-news">
                    <div class="wrap-flex">
                        <span class="sub"><?php echo e(trans('frontend.story.blog_details.related_news')); ?></span>
                        <a href="<?php echo e(route('frontend.blog', ['lang' => app()->getLocale()])); ?>" class="btn-arr back"><?php echo e(trans('frontend.story.blog_details.back_to_news_list')); ?></a>
                    </div>
                    <div class="listing-wrap related">
                        <?php $__currentLoopData = $relatedBlogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relatedBlog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(route('frontend.blog-details', ['lang' => app()->getLocale(), 'blog_id' => $relatedBlog->id, 'titile' => str_replace(' ', '-', $relatedBlog->title)])); ?>" class="list">
                                <figure>
                                    <img src="<?php echo e(asset(!empty($relatedBlog->image) ? $relatedBlog->image : 'frontend/assets/contents/ooLZTrU9bo.jpg')); ?>" alt="">
                                </figure>
                                <div class="text">
                                    <h6><?php echo e($relatedBlog->title ?? ''); ?></h6>
                                    <div class="caption-small">
                                        <span><?php echo e($relatedBlog->blogCategory->name); ?></span>
                                        <span class="date"><?php echo e($relatedBlog->created_at->format('d M Y')); ?></span>
                                    </div>
                                </div>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Works\project outline\faito_appkk\faito_app\resources\views/frontend/story/news/blog-details.blade.php ENDPATH**/ ?>