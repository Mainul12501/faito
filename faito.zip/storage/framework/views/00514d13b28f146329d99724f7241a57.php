

<?php $__env->startSection('title', isset($motorBike) ? 'Edit' : 'Create'.' Motor Bike'); ?>

<?php $__env->startSection('body'); ?>
    <div class="row mt-5">
        <div class="col-md-12 mx-auto">
            <div class="card">
                <div class="card-header bg-light">
                    <h3><?php echo e(isset($motorBike) ? 'update' : 'Create'); ?>Motor Bike</h3>
                    <a href="<?php echo e(route('admin.motor-bikes.index')); ?>" class="btn btn-success btn-sm position-absolute me-5"
                        style="right: 0"><i class="fa fa-sliders"></i></a>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(isset($motorBike) ? route('admin.motor-bikes.update', $motorBike->id) : route('admin.motor-bikes.store')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php if(isset($motorBike)): ?>
                            <?php echo method_field('put'); ?>
                        <?php endif; ?>

                        <div class="row mt-3">
                            <div class="col-md-4">
                                <label for="" class=""> Bike Brand Name</label>
                                <div class="">
                                    <select name="bike_brand_id" class=" form-control " data-toggle="select"
                                        data-placeholder="Choose ...">
                                        <option value="">Select a Bike Brand</option>
                                        <?php $__currentLoopData = $bikeBrands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bikeBrand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($bikeBrand->id); ?>"
                                                <?php echo e($errors->any() ? old('bike_brand_id') : (isset($motorBike) && $motorBike->bike_brand_id == $bikeBrand->id ? 'selected' : '')); ?>>
                                                <?php echo e($bikeBrand->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <?php $__errorArgs = ['bike_brand_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($errors->first('bike_brand_id')); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>


                            <div class="col-md-4">
                                <label for="" class=""> Bike Enzine Size </label>
                                <div class="">
                                    <select name="bike_engine_size_id" class=" form-control " data-toggle="select"
                                        data-placeholder="Choose ...">
                                        <option value="">Select a Bike Engine Size</option>
                                        <?php $__currentLoopData = $bikeEngineSizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bikeEngineSize): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($bikeEngineSize->id); ?>"
                                                <?php echo e($errors->any() ? old('bike_engine_size_id') : (isset($motorBike) && $motorBike->bike_engine_size_id == $bikeEngineSize->id ? 'selected' : '')); ?>>
                                                <?php echo e($bikeEngineSize->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <?php $__errorArgs = ['bike_engine_size_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($errors->first('bike_engine_size_id')); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>



                            <div class="col-md-4">
                                <label for="" class=""> Bike Motor Type</label>

                                <select name="bike_motor_type_id" class=" form-control " data-toggle="select"
                                    data-placeholder="Choose ...">
                                    <option value="">Select a Bike Motor Type</option>
                                    <?php $__currentLoopData = $bikeMotorTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bikeMotorType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($bikeMotorType->id); ?>"
                                            <?php echo e($errors->any() ? old('bike_motor_type_id') : (isset($motorBike) && $motorBike->bike_motor_type_id == $bikeMotorType->id ? 'selected' : '')); ?>>
                                            <?php echo e($bikeMotorType->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <?php $__errorArgs = ['bike_motor_type_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($errors->first('bike_motor_type_id')); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="row mt-3">
                            <div class="col-md-4">
                                <label for="" class=""> Bike Year Version</label>
                                <div class="">
                                    <select name="bike_year_version_id" class=" form-control " data-toggle="select"
                                        data-placeholder="Choose ...">
                                        <option value="">Select a Bike Year Version</option>
                                        <?php $__currentLoopData = $bikeYearVersions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bikeYearVersion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($bikeYearVersion->id); ?>"
                                                <?php echo e($errors->any() ? old('bike_year_version_id') : (isset($motorBike) && $motorBike->bike_year_version_id == $bikeYearVersion->id ? 'selected' : '')); ?>>
                                                <?php echo e($bikeYearVersion->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <?php $__errorArgs = ['bike_year_version_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($errors->first('bike_year_version_id')); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-4">
                                <label for="" class="">Model Name</label>
                                <div class="">
                                    <input type="text" name="model_name" class="form-control"
                                        value="<?php echo e(isset($motorBike) ? $motorBike->model_name : ''); ?>"
                                        placeholder=" Motor Bike Model Name" />
                                </div>
                                <?php $__errorArgs = ['model_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($errors->first('model_name')); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-4">
                                <label for="" class="">Size</label>
                                <div class="">
                                    <input type="text" name="size" class="form-control"
                                        value="<?php echo e(isset($motorBike) ? $motorBike->size : ''); ?>"
                                        placeholder=" Motor Bike Size" />
                                </div>
                                <?php $__errorArgs = ['size'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($errors->first('size')); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>


                            <div class="row mt-4">
                                <div class="col-md-4">
                                    <label for="" class="">Variant</label>
                                    <div class="">
                                        <input type="text" name="variant" class="form-control"
                                            value="<?php echo e(isset($motorBike) ? $motorBike->variant : ''); ?>"
                                            placeholder=" Motor Bike Variant" />
                                    </div>
                                    <?php $__errorArgs = ['variant'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($errors->first('variant')); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>


                                <div class="col-md-4">
                                    <label for="" class="">Sku</label>
                                    <div class="">
                                        <input type="text" name="sku" class="form-control"
                                            value="<?php echo e(isset($motorBike) ? $motorBike->sku : ''); ?>"
                                            placeholder=" Motor Bike Sku" />
                                    </div>
                                    <?php $__errorArgs = ['sku'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($errors->first('sku')); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-md-4">
                                    <label for="" class="">Image</label>
                                    <div class="">
                                        <input type="file" name="image" class="form-control"
                                            placeholder="Bike Motor Type Image" accept="" id="imagez">
                                        <?php if(isset($motorBike)): ?>
                                            <img src="<?php echo e(asset($motorBike->image)); ?>" alt=""
                                                style="height: 80px">
                                        <?php endif; ?>
                                        <span class="text-danger">Min resolution 500 * 500 px</span>
                                    </div>
                                    <div class="col-md-3 mt-2">
                                        <div>
                                            <img src="" id="imagePreview" alt="">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row mt-3">
                                <div class="col-md-3">
                                    <label for="" class="">Status</label>
                                    <div class="">
                                        <div class="material-switch">
                                            <input id="someSwitchOptionLight" name="status" type="checkbox"
                                                <?php echo e(isset($motorBike) && $motorBike->status == 0 ? '' : 'checked'); ?> />
                                            <label for="someSwitchOptionLight" class="label-light"></label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row mt-3">
                                <label for="" class="col-md-3"></label>
                                <div class="col-md-9">
                                    <input type="submit" class="btn btn-success"
                                           value="<?php echo e(isset($motorBike) ? 'update' : 'Create'); ?> Motor Bike">
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        $(document).ready(function() {
            $('#imagez').change(function() {
                var imgURL = URL.createObjectURL(event.target.files[0]);
                $('#imagePreview').attr('src', imgURL).css({
                    height: 100+'px',
                    width: 250+'px',
                    marginTop: '5px'
                });
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/twowheel/faito.twowheelersbd.com/resources/views/backend/bike-management/motor-bike/create.blade.php ENDPATH**/ ?>