<footer>
    <a target="_blank" href="https://api.whatsapp.com/send?phone=+628111616466" class="live-wa">
        <figure><img src="<?php echo e(asset('/')); ?>frontend/assets/images/material/ic-wa.png" alt=""></figure>
        <div class="text">
            <h5>Whatsapp</h5>
            <h3>Live Chat</h3>
        </div>
    </a>
    <div class="wrapper">
        <div class="left-foot">
            <div class="box">
                <a href="#" class="logo-foot"><img src="<?php echo e(asset(!empty($siteSetting->footer_logo) ? $siteSetting->footer_logo : 'frontend/assets/contents/vVGqW50UMC.svg')); ?>" alt=""></a>
            </div>
            <div class="box">




                <p><b>Head Office :</b> 9/3 shahinoor street, west aganagar, keranigonj 1100. Dhaka, Dhaka Division, Bangladesh</p>
            </div>
            <div class="box">
                <?php $__currentLoopData = $siteSettings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siteSetting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span>T. <a href="tel:<?php echo e($siteSetting->helpline_number); ?>"><?php echo e($siteSetting->helpline_number); ?></a></span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <span>E. <a href="mailto:<?php echo e($siteSetting->email); ?>"><?php echo e($siteSetting->email); ?></a></span>
            </div>
        </div>
        <div class="right-foot">
            <small>Faito Careline</small>
            <?php $__currentLoopData = $siteSettings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siteSetting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="tel:<?php echo e($siteSetting->helpline_number); ?>" class="telp"><?php echo e($siteSetting->helpline_number); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="quicklink">
                <ul>
                    <li>
                        <a class="" href="<?php echo e(route('frontend.home')); ?>">
                            <?php echo e(trans('frontend.menu.home')); ?>

                        </a>

                    </li>
                    <li>
                        <a class="" href="<?php echo e(route('frontend.faitology')); ?>">
                            <?php echo e(trans('frontend.menu.story')); ?>

                        </a>

                    </li>
                    <li>
                        <a class="" href="#">
                            <?php echo e(trans('frontend.menu.product')); ?>

                        </a>

                    </li>
                    <li>
                        <a class="" href="<?php echo e(route('frontend.contact')); ?>">
                            <?php echo e(trans('frontend.menu.contact')); ?>

                        </a>

                    </li>
                    <li>
                        <a class="" href="<?php echo e(route('frontend.faq')); ?>">
                            <?php echo e(trans('frontend.menu.faq')); ?>

                        </a>

                    </li>
                </ul>
            </div>
            <div class="medsos-foot">
                <?php $__currentLoopData = $siteSettings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siteSetting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e($siteSetting->fb_link ?? ''); ?>" rel="nofollow" target="_blank"><img src="<?php echo e(asset('/')); ?>frontend/assets/contents/DL94PSMnkG.png" alt=""></a>
                    <a href="<?php echo e($siteSetting->tiktok_link ?? ''); ?>" rel="nofollow" target="_blank"><img src="<?php echo e(asset('/')); ?>frontend/assets/contents/G6cXnP7XQs.png" alt=""></a>
                    <a href="<?php echo e($siteSetting->insta_link ?? ''); ?>" rel="nofollow" target="_blank"><img src="<?php echo e(asset('/')); ?>frontend/assets/contents/8kSM0H9toL.png" alt=""></a>
                    <a href="<?php echo e($siteSetting->youtube_link ?? ''); ?>" rel="nofollow" target="_blank"><img src="<?php echo e(asset('/')); ?>frontend/assets/contents/lLW3VdDELH.png" alt=""></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    <div class="bottom-foot">
        <p>Copyrights <?php echo e(date('Y')); ?> © PT Faito Racing Development Indonesia.  All Rights Reserved</p>
    </div>
</footer>
<?php /**PATH /home/twowheel/faito.twowheelersbd.com/resources/views/frontend/includes/footer.blade.php ENDPATH**/ ?>