<footer>
    <a target="_blank" href="https://api.whatsapp.com/send?phone=+628111616466" class="live-wa">
        <figure><img src="<?php echo e(asset('/')); ?>frontend/assets/images/material/ic-wa.png" alt=""></figure>
        <div class="text">
            <h5>Whatsapp</h5>
            <h3>Live Chat</h3>
        </div>
    </a>
    <div class="wrapper">
        <div class="left-foot">
            <div class="box">
                <a href="#" class="logo-foot"><img src="<?php echo e(asset('/')); ?>frontend/assets/contents/vVGqW50UMC.svg" alt=""></a>
            </div>
            <div class="box">
                <h6>PT FAITO RACING DEVELOPMENT INDONESIA</h6>
                <p><b>Head Office :</b>The Boulevard No. 53
                    Jakarta Garden City
                    Jakarta Timur 13910</p>
            </div>
            <div class="box">
                <span>T. <a href="tel:0811 1616 466">0811 1616 466</a></span>
                <span>E. <a href="mailto:customercare@faito.co.id">customercare@faito.co.id</a></span>
            </div>
        </div>
        <div class="right-foot">
            <small>Faito Careline</small>
            <a href="tel:0811 1616 466" class="telp">0811 1616 466</a>
            <div class="quicklink">
                <ul>
                    <li>
                        <a class="" href="<?php echo e(route('frontend.home')); ?>">
                            Home
                        </a>

                    </li>
                    <li>
                        <a class="" href="<?php echo e(route('frontend.faitology')); ?>">
                            Story
                        </a>

                    </li>
                    <li>
                        <a class="" href="<?php echo e(route('frontend.product')); ?>">
                            Product
                        </a>

                    </li>
                    <li>
                        <a class="" href="<?php echo e(route('frontend.contact')); ?>">
                            Contact
                        </a>

                    </li>
                    <li>
                        <a class="" href="<?php echo e(route('frontend.faq')); ?>">
                            FAQ
                        </a>

                    </li>
                </ul>
            </div>
            <div class="medsos-foot">
                <a href="https://www.facebook.com/FaitoRacingID/" rel="nofollow" target="_blank"><img src="<?php echo e(asset('/')); ?>frontend/assets/contents/DL94PSMnkG.png" alt=""></a>
                <a href="https://www.tiktok.com/@faitoindonesiaofficial" rel="nofollow" target="_blank"><img src="<?php echo e(asset('/')); ?>frontend/assets/contents/G6cXnP7XQs.png" alt=""></a>
                <a href="https://www.instagram.com/faitoindonesia" rel="nofollow" target="_blank"><img src="<?php echo e(asset('/')); ?>frontend/assets/contents/8kSM0H9toL.png" alt=""></a>
                <a href="https://www.youtube.com/channel/UCkPIrlLlDTeu5aVX7orJqZQ" rel="nofollow" target="_blank"><img src="<?php echo e(asset('/')); ?>frontend/assets/contents/lLW3VdDELH.png" alt=""></a>
            </div>
        </div>
    </div>
    <div class="bottom-foot">
        <p>Copyrights <?php echo e(date('Y')); ?> © PT Faito Racing Development Indonesia.  All Rights Reserved</p>
    </div>
</footer>
<?php /**PATH D:\xampp\htdocs\faito_app\resources\views/frontend/includes/footer.blade.php ENDPATH**/ ?>