<?php $__env->startSection('title', 'Faq'); ?>

<?php $__env->startSection('body'); ?>
    <div class="row mt-5">
        <div class="col-md-7 mx-auto">
            <div class="card">
                <div class="card-header bg-light">
                    <h3><?php echo e(isset($faq) ? 'update' : 'Create'); ?> Faq </h3>
                    <a href="<?php echo e(route('admin.faqs.index')); ?>" class="btn btn-success btn-sm position-absolute me-5" style="right: 0"><i class="fa fa-sliders"></i></a>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(isset($faq) ? route('admin.faqs.update', $faq->id) : route('admin.faqs.store')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php if(isset($faq)): ?>
                            <?php echo method_field('put'); ?>
                        <?php endif; ?>
                        <div class="row mt-3">
                            <label for="" class="col-md-3">Question</label>
                            <div class="col-md-9">
                                <input type="text" name="question" required class="form-control" value="<?php echo e(isset($faq) ? $faq->question : ''); ?>" placeholder="Question" />
                            </div>
                            <?php $__errorArgs = ['question'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($errors->first('question')); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="row mt-3">
                            <div class="col-12">
                                <label for="" class="">Answer</label>
                                <div class="">
                                    <textarea name="answer" id="" required class="form-control ckeditor" placeholder="Answer"><?php echo e(isset($faq) ? $faq->answer : ''); ?></textarea>
                                </div>
                            </div>
                        </div>
                        <div class="row mt-3">
                            <label for="" class="col-md-3">Status</label>
                            <div class="col-md-9">
                                <div class="material-switch">
                                    <input id="someSwitchOptionLight" name="status" type="checkbox" <?php echo e(isset($faq) && $faq->status == 0 ? '' : 'checked'); ?> />
                                    <label for="someSwitchOptionLight" class="label-light"></label>
                                </div>
                            </div>
                        </div>
                        <div class="row mt-3">
                            <label for="" class="col-md-3"></label>
                            <div class="col-md-9">
                                <input type="submit" class="btn btn-success" value="<?php echo e(isset($faq) ? 'update' : 'Create'); ?> Faq ">
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Works\laravel\faito_app_updated_09022024\faito_app\resources\views/backend/additional-features/faqs/form.blade.php ENDPATH**/ ?>