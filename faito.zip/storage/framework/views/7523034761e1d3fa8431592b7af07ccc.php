<?php $__env->startSection('body'); ?>
    <section class="banner-landing">
        <figure>
            <img src="<?php echo e(asset('/')); ?>frontend/assets/contents/rxITWU03xa.jpg" alt="">
        </figure>
        <div class="text-absolute">
            <h2><?php echo e(trans('frontend.story.testimonial.testimonial_upper')); ?></h2>
            <span><img src="<?php echo e(asset('/')); ?>frontend/assets/images/material/shape-img-abs.png" alt=""></span>
        </div>
        <span class="shape-banner"><img src="<?php echo e(asset('/')); ?>frontend/assets/images/material/shape-banner.png" alt=""></span>
    </section>

    <section class="content-landing testi">
        <div class="wrapper">
            <div class="middle">
                <div class="title-landing no-text-right">
                    <div class="title">
                        <span class="line-text"></span>
                        <small><?php echo e(trans('frontend.story.testimonial.testimonial')); ?></small>
                        <h3><?php echo e(trans('frontend.story.testimonial.testimonial')); ?></h3>
                    </div>
                </div>
                <div class="box-slider-testi">
                    <div class="slider-testimonial">
                        <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="list-testi">
                            <div class="inner">
                                <h3><?php echo e($testimonial->partsProduct->title ?? ''); ?></h3>
                                <p><img style="display: block; margin-left: auto; margin-right: auto;" src="<?php echo e(asset(!empty($testimonial->partsProduct->main_image) ? $testimonial->partsProduct->main_image : 'admin/no-img/no-image.jpeg')); ?>" alt="" width="534" height="468" /></p>
                                <p><?php echo $testimonial->message ?? ''; ?></p>
                                <div class="profile">
                                    <figure>
                                        <img src="<?php echo e(asset(!empty($testimonial->user_image) ? $testimonial->user_image : 'frontend/assets/contents/RMCJ3XziEN.png')); ?>" alt="">
                                    </figure>
                                    <div class="tagprofile">
                                        <h5><?php echo e($testimonial->user_name ?? ''); ?></h5>
                                        <p><?php echo e($testimonial->user_designation); ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="indicator-slider">
          <span class="number-slider">
            <span class="number-in-slider"></span> of <span class="count-in-slider"></span>
          </span>
                        <div class="line-indicator-slider">
                            <span></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mainul Islam\Downloads\Compressed\temp\faito-app\faito_app\resources\views/frontend/story/testimonial/index.blade.php ENDPATH**/ ?>