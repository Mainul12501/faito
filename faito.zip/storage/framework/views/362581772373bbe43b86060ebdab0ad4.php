<?php $__env->startSection('body'); ?>
    <section class="banner-landing">
        <figure>
            <img src="<?php echo e(asset('/')); ?>frontend/assets/contents/aDjPKRIUf5.png" alt="">
        </figure>
        <div class="text-absolute">
            <h2><?php echo e($motorType->name ?? 'Type Name'); ?></h2>
            <span><img src="<?php echo e(asset('/')); ?>frontend/assets/images/material/shape-img-abs.png" alt=""></span>
        </div>
        <span class="shape-banner"><img src="<?php echo e(asset('/')); ?>frontend/assets/images/material/shape-banner.png" alt=""></span>
    </section>


    <section class="content-landing testi">
        <div class="wrapper">
            <div class="box-grid">
                <?php if(!empty($bikeBrands)): ?>
                    <?php $__currentLoopData = $bikeBrands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bikeBrand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('frontend.category-wise-bikes', ['bike_brand_id' => $bikeBrand->id, 'brand_name' => str_replace(' ', '-', $bikeBrand->name)])); ?>" class="box big">
                            <figure>
                                <img src="<?php echo e(asset(!empty($bikeBrand) ? $bikeBrand->logo : 'admin/no-img/no-image.png')); ?>" alt="">
                                <figcaption>
                                    <h5><?php echo e($bikeBrand->name ?? 'Brand Name'); ?></h5>
                                    <span>View All</span>
                                </figcaption>
                            </figure>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>

        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mainul Islam\Downloads\Compressed\temp\faito-app\faito_app_06032024\faito_app\resources\views/frontend/product/bike-brand.blade.php ENDPATH**/ ?>