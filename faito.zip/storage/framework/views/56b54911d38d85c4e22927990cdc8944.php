<?php $__env->startSection('body'); ?>
    <section class="banner-landing">
        <figure>
            <img src="<?php echo e(asset('/')); ?>frontend/assets/contents/aDjPKRIUf5.png" alt="">
        </figure>
        <div class="text-absolute">
            <h2>Yamaha</h2>
            <span><img src="<?php echo e(asset('/')); ?>frontend/assets/images/material/shape-img-abs-red.png" alt=""></span>
        </div>
        <span class="shape-banner"><img src="<?php echo e(asset('/')); ?>frontend/assets/images/material/shape-banner-red.png" alt=""></span>
    </section>


    <section class="content-landing testi">
        <div class="wrapper">
            <div class="box-grid">
                <a href="../../../searchd46d.html?motortype=bebek&amp;brand=yamaha&amp;motor=cripton" class="box big">
                    <figure>
                        <img src="<?php echo e(asset('/')); ?>frontend/assets/contents/VWcgAS4aiE.jpg" alt="">
                        <figcaption>
                            <h5>Cripton</h5>
                            <span>View All</span>
                        </figcaption>
                    </figure>
                </a>


                <a href="../../../search01ef.html?motortype=bebek&amp;brand=yamaha&amp;motor=f1z" class="box big">
                    <figure>
                        <img src="<?php echo e(asset('/')); ?>frontend/assets/contents/FU4PNYuHTF.jpg" alt="">
                        <figcaption>
                            <h5>F1Z</h5>
                            <span>View All</span>
                        </figcaption>
                    </figure>
                </a>


                <a href="../../../search0154.html?motortype=bebek&amp;brand=yamaha&amp;motor=f1zr-1" class="box big">
                    <figure>
                        <img src="<?php echo e(asset('/')); ?>frontend/assets/contents/vgBwBaX6LT.jpg" alt="">
                        <figcaption>
                            <h5>F1ZR</h5>
                            <span>View All</span>
                        </figcaption>
                    </figure>
                </a>


                <a href="../../../searcha4b0.html?motortype=bebek&amp;brand=yamaha&amp;motor=f1zr" class="box big">
                    <figure>
                        <img src="<?php echo e(asset('/')); ?>frontend/assets/contents/OpsHy0xieo.jpg" alt="">
                        <figcaption>
                            <h5>F1ZR</h5>
                            <span>View All</span>
                        </figcaption>
                    </figure>
                </a>


                <a href="../../../search7f22.html?motortype=bebek&amp;brand=yamaha&amp;motor=force-1" class="box big">
                    <figure>
                        <img src="<?php echo e(asset('/')); ?>frontend/assets/contents/hUGEBl5D81.jpg" alt="">
                        <figcaption>
                            <h5>Force 1</h5>
                            <span>View All</span>
                        </figcaption>
                    </figure>
                </a>


                <a href="../../../search58ea.html?motortype=bebek&amp;brand=yamaha&amp;motor=force-1-new" class="box big">
                    <figure>
                        <img src="<?php echo e(asset('/')); ?>frontend/assets/contents/lgM5sckDEs.jpg" alt="">
                        <figcaption>
                            <h5>Force 1 New</h5>
                            <span>View All</span>
                        </figcaption>
                    </figure>
                </a>


                <a href="../../../search0651.html?motortype=bebek&amp;brand=yamaha&amp;motor=jupiter" class="box big">
                    <figure>
                        <img src="<?php echo e(asset('/')); ?>frontend/assets/contents/nSuu74wjsq.jpg" alt="">
                        <figcaption>
                            <h5>Jupiter</h5>
                            <span>View All</span>
                        </figcaption>
                    </figure>
                </a>


                <a href="../../../search7881.html?motortype=bebek&amp;brand=yamaha&amp;motor=jupiter-155-z-new" class="box big">
                    <figure>
                        <img src="<?php echo e(asset('/')); ?>frontend/assets/contents/3DozD8RU5i.jpg" alt="">
                        <figcaption>
                            <h5>Jupiter 115 Z New</h5>
                            <span>View All</span>
                        </figcaption>
                    </figure>
                </a>


                <a href="../../../search975c.html?motortype=bebek&amp;brand=yamaha&amp;motor=jupiter-mx" class="box big">
                    <figure>
                        <img src="<?php echo e(asset('/')); ?>frontend/assets/contents/Qhho3jbDYh.jpg" alt="">
                        <figcaption>
                            <h5>Jupiter MX</h5>
                            <span>View All</span>
                        </figcaption>
                    </figure>
                </a>


                <a href="../../../searchb4c2.html?motortype=bebek&amp;brand=yamaha&amp;motor=jupiter-mx-clutch-08" class="box big">
                    <figure>
                        <img src="<?php echo e(asset('/')); ?>frontend/assets/contents/MCTPqvmifb.jpg" alt="">
                        <figcaption>
                            <h5>Jupiter MX (Clutch-08)</h5>
                            <span>View All</span>
                        </figcaption>
                    </figure>
                </a>


                <a href="../../../searcha51a.html?motortype=bebek&amp;brand=yamaha&amp;motor=jupiter-mx-clutch-09" class="box big">
                    <figure>
                        <img src="<?php echo e(asset('/')); ?>frontend/assets/contents/dDDZjOe4t8.jpg" alt="">
                        <figcaption>
                            <h5>Jupiter MX (Clutch-09)</h5>
                            <span>View All</span>
                        </figcaption>
                    </figure>
                </a>


                <a href="../../../search161d.html?motortype=bebek&amp;brand=yamaha&amp;motor=jupiter-mx-clutch-10-1" class="box big">
                    <figure>
                        <img src="<?php echo e(asset('/')); ?>frontend/assets/contents/aoeIZDO9Pb.jpg" alt="">
                        <figcaption>
                            <h5>Jupiter MX (Clutch-10)</h5>
                            <span>View All</span>
                        </figcaption>
                    </figure>
                </a>


                <a href="../../../search4cde.html?motortype=bebek&amp;brand=yamaha&amp;motor=jupiter-mx-clutch" class="box big">
                    <figure>
                        <img src="<?php echo e(asset('/')); ?>frontend/assets/contents/RRqcZlbeQ3.jpg" alt="">
                        <figcaption>
                            <h5>Jupiter MX (Clutch)</h5>
                            <span>View All</span>
                        </figcaption>
                    </figure>
                </a>


                <a href="../../../searchb333.html?motortype=bebek&amp;brand=yamaha&amp;motor=jupiter-mx-5-speed" class="box big">
                    <figure>
                        <img src="<?php echo e(asset('/')); ?>frontend/assets/contents/2z9Kv9xuXw.jpg" alt="">
                        <figcaption>
                            <h5>Jupiter MX 5 Speed</h5>
                            <span>View All</span>
                        </figcaption>
                    </figure>
                </a>


                <a href="../../../searchee8e.html?motortype=bebek&amp;brand=yamaha&amp;motor=jupiter-mx-king-150" class="box big">
                    <figure>
                        <img src="<?php echo e(asset('/')); ?>frontend/assets/contents/Q1xhpZPwWJ.jpg" alt="">
                        <figcaption>
                            <h5>Jupiter MX King 150</h5>
                            <span>View All</span>
                        </figcaption>
                    </figure>
                </a>


                <a href="../../../searche1fd.html?motortype=bebek&amp;brand=yamaha&amp;motor=jupiter-z" class="box big">
                    <figure>
                        <img src="<?php echo e(asset('/')); ?>frontend/assets/contents/82mTjPuXUJ.jpg" alt="">
                        <figcaption>
                            <h5>Jupiter Z</h5>
                            <span>View All</span>
                        </figcaption>
                    </figure>
                </a>


                <a href="../../../search0c75.html?motortype=bebek&amp;brand=yamaha&amp;motor=jupiter-z1-f-i" class="box big">
                    <figure>
                        <img src="<?php echo e(asset('/')); ?>frontend/assets/contents/rrEqODRIQA.jpg" alt="">
                        <figcaption>
                            <h5>Jupiter Z1 F.I</h5>
                            <span>View All</span>
                        </figcaption>
                    </figure>
                </a>


                <a href="../../../search147a.html?motortype=bebek&amp;brand=yamaha&amp;motor=lexam" class="box big">
                    <figure>
                        <img src="<?php echo e(asset('/')); ?>frontend/assets/contents/k4SeiBHEz9.jpg" alt="">
                        <figcaption>
                            <h5>Lexam</h5>
                            <span>View All</span>
                        </figcaption>
                    </figure>
                </a>


                <a href="../../../search1fb3.html?motortype=bebek&amp;brand=yamaha&amp;motor=new-vega-r" class="box big">
                    <figure>
                        <img src="<?php echo e(asset('/')); ?>frontend/assets/contents/fQ6w2Pls4S.jpg" alt="">
                        <figcaption>
                            <h5>New Vega R</h5>
                            <span>View All</span>
                        </figcaption>
                    </figure>
                </a>


                <a href="../../../searchff70.html?motortype=bebek&amp;brand=yamaha&amp;motor=vega" class="box big">
                    <figure>
                        <img src="<?php echo e(asset('/')); ?>frontend/assets/contents/rGOSRRu82x.jpg" alt="">
                        <figcaption>
                            <h5>Vega</h5>
                            <span>View All</span>
                        </figcaption>
                    </figure>
                </a>


                <a href="../../../searchbca1.html?motortype=bebek&amp;brand=yamaha&amp;motor=vega-force" class="box big">
                    <figure>
                        <img src="<?php echo e(asset('/')); ?>frontend/assets/contents/i6mJow6QtQ.jpg" alt="">
                        <figcaption>
                            <h5>Vega Force</h5>
                            <span>View All</span>
                        </figcaption>
                    </figure>
                </a>


                <a href="../../../searche34d.html?motortype=bebek&amp;brand=yamaha&amp;motor=jupiter-1" class="box big">
                    <figure>
                        <img src="<?php echo e(asset('/')); ?>frontend/assets/contents/O5d6gUzDnH.jpg" alt="">
                        <figcaption>
                            <h5>Vega RR</h5>
                            <span>View All</span>
                        </figcaption>
                    </figure>
                </a>


                <a href="../../../searchc732.html?motortype=bebek&amp;brand=yamaha&amp;motor=vega-zr-fi" class="box big">
                    <figure>
                        <img src="<?php echo e(asset('/')); ?>frontend/assets/contents/lEvFRsioxz.jpg" alt="">
                        <figcaption>
                            <h5>Vega ZR</h5>
                            <span>View All</span>
                        </figcaption>
                    </figure>
                </a>


                <a href="../../../search5fae.html?motortype=bebek&amp;brand=yamaha&amp;motor=y125z" class="box big">
                    <figure>
                        <img src="<?php echo e(asset('/')); ?>frontend/assets/contents/JCc8skZ4Wm.jpg" alt="">
                        <figcaption>
                            <h5>Y125Z</h5>
                            <span>View All</span>
                        </figcaption>
                    </figure>
                </a>


            </div>

        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Works\laravel\faito_app_updated_09022024\faito_app\resources\views/frontend/product/bike.blade.php ENDPATH**/ ?>