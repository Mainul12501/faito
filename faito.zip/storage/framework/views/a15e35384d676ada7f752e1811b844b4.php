<header class="<?php echo e(isset($is_nobanner) ? 'nobanner' : ''); ?>">
    <div class="wrapper">
        <div class="logo white">
            <a
                target="_self"
                href="<?php echo e(route('frontend.home')); ?>">
                <img src="<?php echo e(asset('/')); ?>frontend/assets/contents/4dVXEf6gSg.png" alt="" />
            </a>
            <?php $__currentLoopData = $partsParentBrands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partsParentBrand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a
                target="_self"
                href="<?php echo e(route('frontend.product-search', ['brand_id' => $partsParentBrand->id])); ?>">
                    <img src="<?php echo e(asset(!empty($partsParentBrand->logo) ? $partsParentBrand->logo : 'frontend/assets/contents/Xuczl0Gp6S.svg')); ?>" alt="" style="height: 35px;" />
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="logo black">
            <a
                target="_self"
                href="<?php echo e(route('frontend.home')); ?>">
                <img src="<?php echo e(asset('/')); ?>frontend/assets/contents/mwCf0qfJ80.svg"
                     alt=""></a>
            <?php $__currentLoopData = $partsParentBrands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partsParentBrand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a
                target="_self"
                href="<?php echo e(route('frontend.product-search', ['brand_id' => $partsParentBrand->id])); ?>">
                        <img src="<?php echo e(asset(!empty($partsParentBrand->logo) ? $partsParentBrand->logo : 'frontend/assets/contents/Xuczl0Gp6S.svg')); ?>" alt="" style="height: 35px;" />
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php echo $__env->make('frontend.includes.right-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="togglemenu" >
            <span></span>
            <span></span>
            <span></span>
        </div>
    </div>
</header>

<?php echo $__env->make('frontend.includes.popupsearch', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('frontend.includes.burgermenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /home/twowheel/faito.twowheelersbd.com/resources/views/frontend/includes/header.blade.php ENDPATH**/ ?>