<!-- BOOTSTRAP CSS -->
<link id="style" href="<?php echo e(asset('/')); ?>backend/assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" />

<!-- STYLE CSS -->
<link href="<?php echo e(asset('/')); ?>backend/assets/css/style.css" rel="stylesheet" />
<link href="<?php echo e(asset('/')); ?>backend/assets/css/skin-modes.css" rel="stylesheet" />

<!--- FONT-ICONS CSS -->
<link href="<?php echo e(asset('/')); ?>backend/assets/plugins/icons/icons.css" rel="stylesheet" />

<!-- INTERNAL Switcher css -->
<link href="<?php echo e(asset('/')); ?>backend/assets/switcher/css/switcher.css" rel="stylesheet">
<link href="<?php echo e(asset('/')); ?>backend/assets/switcher/demo.css" rel="stylesheet">


<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" integrity="sha512-vKMx8UnXk60zUwyUnUPM3HbQo8QfmNx7+ltw8Pm5zLusl1XIfwcxo8DbWCqMGKaWeNxWA8yrx5v3SaVpMvR3CA==" crossorigin="anonymous" referrerpolicy="no-referrer" />

<?php echo $__env->yieldPushContent('style'); ?>
<?php echo $__env->yieldContent('style'); ?>
<?php /**PATH C:\Users\Mainul Islam\Downloads\Compressed\temp\faito-app\faito_app\resources\views/backend/includes/assets/style.blade.php ENDPATH**/ ?>