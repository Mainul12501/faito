<link rel="stylesheet" href="<?php echo e(asset('/')); ?>frontend/assets/fe/css/styles.min.css">

<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" integrity="sha512-vKMx8UnXk60zUwyUnUPM3HbQo8QfmNx7+ltw8Pm5zLusl1XIfwcxo8DbWCqMGKaWeNxWA8yrx5v3SaVpMvR3CA==" crossorigin="anonymous" referrerpolicy="no-referrer" />



<?php echo $__env->yieldContent('css'); ?>
<?php echo $__env->yieldPushContent('css'); ?>
<?php /**PATH C:\Users\Mainul Islam\Downloads\Compressed\temp\faito-app\faito_app_06032024\faito_app\resources\views/frontend/includes/assets/css.blade.php ENDPATH**/ ?>