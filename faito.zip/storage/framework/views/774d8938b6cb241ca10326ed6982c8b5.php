<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('body'); ?>
    <section class="banner-landing">
        <figure>
            <img src="<?php echo e(asset('/')); ?>frontend/assets/contents/x4ZsrY20hD.jpg" alt="">
        </figure>
        <div class="text-absolute">
            <h2><?php echo e($brand->name ?? ''); ?></h2>
            <span><img src="<?php echo e(asset('/')); ?>frontend/assets/images/material/shape-img-abs.png" alt=""></span>
        </div>
        <span class="shape-banner"><img src="<?php echo e(asset('/')); ?>frontend/assets/images/material/shape-banner.png" alt=""></span>
    </section>


    <section class="content-landing testi">
        <div class="wrapper">
            <div class="middle">
                <div class="title-landing">
                    <div class="title">
                        <span class="line-text"></span>
                        <small><?php echo e($brand->name ?? ''); ?></small>
                        <h3><?php echo e($brand->name ?? ''); ?></h3>
                    </div>
                    <div class="text-right">
                        <p style="text-align: justify;"><?php echo $brand->description ?? ''; ?></p>
                    </div>
                </div>
            </div>
            <div class="box-grid">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('frontend.sub-cat', ['parts_parent_brand_category_id' => $category->id, 'name' => str_replace(' ', '-', $category->name)])); ?>" class="box">
                        <figure>
                        <img src="<?php echo e(asset(!empty($category->image) ? $category->image : 'frontend/assets/contents/rsQC1C7Fkq.png')); ?>" alt="" />
                        <figcaption>
                            <h5><?php echo e($category->name ?? ''); ?></h5>
                            <span>View All</span>
                        </figcaption>
                    </figure>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Works\laravel\faito_app_updated_09022024\faito_app\resources\views/frontend/product/index.blade.php ENDPATH**/ ?>