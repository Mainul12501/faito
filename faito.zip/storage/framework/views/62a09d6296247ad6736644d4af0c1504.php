<link rel="stylesheet" href="<?php echo e(asset('/')); ?>frontend/assets/fe/css/styles.min.css">

<?php echo $__env->yieldContent('css'); ?>
<?php echo $__env->yieldPushContent('css'); ?>
<?php /**PATH D:\Works\laravel\faito_app_updated_09022024\faito_app\resources\views/frontend/includes/assets/css.blade.php ENDPATH**/ ?>