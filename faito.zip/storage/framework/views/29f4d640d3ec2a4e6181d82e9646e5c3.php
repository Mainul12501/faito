

<?php $__env->startSection('title', 'Manage Bike Motor Type'); ?>

<?php $__env->startSection('body'); ?>
    <div class="row mt-5">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header bg-light">
                    <h3>Manage Bike Motor Type</h3>
                    <a href="<?php echo e(route('admin.parts-brand-categories.create', ['parts_brand_category_id' => isset($_GET['parts_brand_category_id']) ? $_GET['parts_brand_category_id'] : 0])); ?>" class="btn btn-success btn-sm position-absolute me-5" style="right: 0"><i class="fa fa-plus-circle"></i></a>
                </div>
                <div class="card-body">
                    <div class="table-responsive export-table">
                    <table class="table" id="file-datatable">
                        <thead>
                        <th>#</th>
                        <th>Parts Parent Brand</th>
                        <th>Name</th>
                        <th>Description</th>
                        <th>Image</th>
                        <th>Status</th>
                        <th>Action</th>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $partsBrandCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partsBrandCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($partsBrandCategory->partsParentBrand->name); ?></td>
                                <td>
                                    <a href="<?php echo e(route('admin.parts-brand-categories.index', ['parts_brand_category_id' => $partsBrandCategory->id])); ?>" class="nav-link text-warning"><?php echo e($partsBrandCategory->name); ?></a>
                                </td>
                                <td><?php echo $partsBrandCategory->description; ?></td>
                                <td><img src="<?php echo e(asset(!empty($partsBrandCategory->image) ? $partsBrandCategory->image : 'admin/no-img/no-image.jpeg' )); ?>" alt="" style="height: 60px"></td>
                                <td><?php echo e($partsBrandCategory->status == 1 ? 'Published' : 'Unpublished'); ?></td>
                                <td class="d-flex">
                                    <a href="<?php echo e(route('admin.parts-brand-categories.edit', $partsBrandCategory->id)); ?>" class="btn btn-sm btn-primary"><i class="fa fa-edit"></i></a>
                                    <form action="<?php echo e(route('admin.parts-brand-categories.destroy', $partsBrandCategory->id)); ?>" method="post" id="deleteItem">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button type="submit" class="btn btn-sm btn-danger ms-1 delete-item"><i class="fa fa-trash"></i></button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mainul Islam\Downloads\Compressed\temp\faito-app\v1\faito_app\resources\views/backend/parts-management/parts-brand-category/index.blade.php ENDPATH**/ ?>