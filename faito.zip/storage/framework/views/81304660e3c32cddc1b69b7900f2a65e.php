

<?php $__env->startSection('title', 'Manage Motor Bike'); ?>

<?php $__env->startSection('body'); ?>
    <div class="row mt-5">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header bg-light">
                    <h3>Manage Motorbike</h3>
                    <a href="<?php echo e(route('admin.motor-bikes.create')); ?>" class="btn btn-success btn-sm position-absolute me-5" style="right: 0"><i class="fa fa-plus-circle"></i></a>
                </div>
                <div class="card-body">
                    <div class="table-responsive export-table">
                    <table class="table" id="file-datatable">
                        <thead>
                        <th>#</th>
                        <th>Bike Brand Name</th>
                        <th>Bike Engine Size Name</th>
                        <th>Bike Motor Type Name</th>
                        <th>Bike Year Version</th>
                        <th>Model Name</th>
                        <th>Size</th>
                        <th>Image</th>
                        <th>Variant</th>
                        <th>Sku</th>
                        <th>Slug</th>
                        <th>Status</th>
                        <th>Action</th>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $motorBikes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $motorBike): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($motorBike->bikeBrand->name); ?></td>
                                <td><?php echo e($motorBike->bikeEngineSize->name); ?></td>
                                <td><?php echo e($motorBike->bikeMotorType->name); ?></td>
                                <td><?php echo e($motorBike->bikeYearVersion->name); ?></td>
                                <td><?php echo e($motorBike->model_name); ?></td>
                                <td><?php echo e($motorBike->size); ?></td>
                                <td><img src="<?php echo e(asset(!empty($motorBike->image) ? $motorBike->image : 'admin/no-img/no-image.jpeg' )); ?>" alt="motorbikes" style="height: 60px"></td>
                                <td><?php echo e($motorBike->variant); ?></td>
                                <td><?php echo e($motorBike->sku); ?></td>
                                <td><?php echo e($motorBike->slug); ?></td>
                                <td><?php echo e($motorBike->status == 1 ? 'Published' : 'Unpublished'); ?></td>

                                <td class="d-flex">
                                    <a href="<?php echo e(route('admin.motor-bikes.edit', $motorBike->id)); ?>" class="btn btn-sm btn-primary"><i class="fa fa-edit"></i></a>
                                    <form action="<?php echo e(route('admin.motor-bikes.destroy', $motorBike->id)); ?>" method="post" id="deleteItem">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button type="submit" class="btn btn-sm btn-danger ms-1 delete-item"><i class="fa fa-trash"></i></button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Works\project outline\faito_appkk\faito_app\resources\views/backend/bike-management/motor-bike/index.blade.php ENDPATH**/ ?>